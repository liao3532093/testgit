CREATE PROCEDURE pro_piling_model(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#渠道模块信息
	DECLARE modelName VARCHAR(255) DEFAULT '';
	DECLARE platId INT DEFAULT 0;
	DECLARE mType INT DEFAULT 0;
	DECLARE requestUrl VARCHAR(255) DEFAULT '';
	DECLARE requestType VARCHAR(255) DEFAULT '';
	DECLARE responseItem VARCHAR(255) DEFAULT '';
	DECLARE state INT DEFAULT 0;
	DECLARE userId INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;
	
	CASE `index`
		WHEN 1 THEN	#添加渠道模块
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET modelName=pro_split_string(`strs`,'|',2);  #模块名称
			SET mType=pro_split_string(`strs`,'|',3);  #模块类型
			SET requestUrl=pro_split_string(`strs`,'|',4);  #请求地址
			SET requestType=pro_split_string(`strs`,'|',5);  #请求方式
			SET responseItem=pro_split_string(`strs`,'|',6);  #返回/请求参数
			SET state=pro_split_string(`strs`,'|',7);  #状态(0:禁用,1:启用)
			SET userId=pro_split_string(`strs`,'|',8);  #用户ID
			SET @id=pro_split_string(`strs`,'|',9);  #ID
			IF @id>0 THEN  #修改
				UPDATE piling_model m SET m.plat_id=platId,m.piling_model_name=modelName,m.request_url=requestUrl,
					m.request_type=requestType,m.response_item=responseItem,m.state=state,m.user_id=userId,m.modelType=mType WHERE m.id=@id;
				SELECT '1';
			ELSE  #添加 
				INSERT INTO piling_model VALUES(NULL,modelName,platId,mType,requestUrl,requestType,responseItem,state,NOW(),userId);
				SELECT '1';
			END IF;
		WHEN 2 THEN #分页查询
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET modelName=pro_split_string(`strs`,'|',2);  #模块名称
			SET mType=pro_split_string(`strs`,'|',3);  #模块类型
			SET page=pro_split_string(`strs`,'|',4);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',5);  #多少条
			IF platId>0 && mType<0 THEN 
				SELECT m.*,f.Title AS platName FROM piling_model m JOIN Dict_PlatForm f WHERE m.plat_id=f.ID AND m.plat_id=platId 
				AND m.piling_model_name LIKE CONCAT('%',modelName,'%') ORDER BY m.id LIMIT page,pageSize;
			ELSEIF platId<0 && mType>0 THEN 
				SELECT m.*,f.Title AS platName FROM piling_model m JOIN Dict_PlatForm f WHERE m.plat_id=f.ID AND m.modelType=mType 
				AND m.piling_model_name LIKE CONCAT('%',modelName,'%') ORDER BY m.id LIMIT page,pageSize;
			ELSE
				SELECT m.*,f.Title AS platName FROM piling_model m JOIN Dict_PlatForm f WHERE m.plat_id=f.ID 
				AND m.piling_model_name LIKE CONCAT('%',modelName,'%') ORDER BY m.id LIMIT page,pageSize;
			END IF;
		WHEN 3 THEN #分页查询个数 
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET modelName=pro_split_string(`strs`,'|',2);  #模块名称
			IF platId>0 THEN 
				SELECT COUNT(*) FROM piling_model m JOIN Dict_PlatForm f WHERE m.plat_id=f.ID AND m.plat_id=platId 
				AND m.piling_model_name LIKE CONCAT('%',modelName,'%') ORDER BY m.id;
			ELSE
				SELECT COUNT(*) FROM piling_model m JOIN Dict_PlatForm f WHERE m.plat_id=f.ID 
				AND m.piling_model_name LIKE CONCAT('%',modelName,'%') ORDER BY m.id;
			END IF;
		WHEN 4 THEN  #禁用和启用
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SET state=(SELECT m.state FROM piling_model m WHERE m.id=@id);
			SET @len=0;
			IF state=1 THEN
				SET @len=0;
			ELSE
				SET @len=1;
			END IF;
			UPDATE piling_model m SET m.state=@len WHERE m.id=@id;
			SELECT '1';
		WHEN 5 THEN #按ID查询
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SET state=pro_split_string(`strs`,'|',2);  #状态(0:禁用,1:启用)
			IF state<=0 THEN
				SELECT * FROM piling_model m WHERE m.id=@id;
			ELSE
				SELECT * FROM piling_model m WHERE m.state=state AND m.id=@id;
			END IF;
		WHEN 6 THEN #查询全部
			SELECT * FROM piling_model m WHERE m.state=1;
	END CASE;
END;
