CREATE PROCEDURE pro_execute(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#校验模块
	DECLARE PlatID INT DEFAULT 0;
	DECLARE ExpectTypeID INT DEFAULT 0;
	DECLARE Title VARCHAR(255) DEFAULT '';
	DECLARE ExecuteSql VARCHAR(255) DEFAULT '';
	DECLARE isEnable INT DEFAULT 0;
	DECLARE AddUserID INT DEFAULT 0;
	DECLARE ExpectValue VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询校验模块
			SET PlatID=pro_split_string(`strs`,'|',1);  #平台ID
			SET ExpectTypeID=pro_split_string(`strs`,'|',2);  #预设ID
			SET page=pro_split_string(`strs`,'|',3);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',4);  #多少条
			IF PlatID>0&&ExpectTypeID<=0 THEN 
				SELECT s.ID,s.PlatID,s.ExPectTypeID,s.Title,s.ExecuteSql,s.IsEnable,s.AddUserID,s.Addtime,s.ExpectValue,p.Title 
					AS platName,t.Title AS expectTypeName FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.PlatID=PlatID ORDER BY s.ID LIMIT page,pageSize;
			ELSEIF ExpectTypeID>0&&PlatID<=0 THEN
				SELECT s.ID,s.PlatID,s.ExPectTypeID,s.Title,s.ExecuteSql,s.IsEnable,s.AddUserID,s.Addtime,s.ExpectValue,p.Title 
					AS platName,t.Title AS expectTypeName FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.ExPectTypeID=ExpectTypeID ORDER BY s.ID LIMIT page,pageSize;
			ELSEIF ExpectTypeID>0&&PlatID>0 THEN 
				SELECT s.ID,s.PlatID,s.ExPectTypeID,s.Title,s.ExecuteSql,s.IsEnable,s.AddUserID,s.Addtime,s.ExpectValue,p.Title 
					AS platName,t.Title AS expectTypeName FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.PlatID=PlatID AND s.ExPectTypeID=ExpectTypeID ORDER BY s.ID LIMIT page,pageSize;
			ELSE
				SELECT s.ID,s.PlatID,s.ExPectTypeID,s.Title,s.ExecuteSql,s.IsEnable,s.AddUserID,s.Addtime,s.ExpectValue,p.Title 
					AS platName,t.Title AS expectTypeName FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID ORDER BY s.ID LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN  #分页查询校验模块个数
			SET PlatID=pro_split_string(`strs`,'|',1);  #平台ID
			SET ExpectTypeID=pro_split_string(`strs`,'|',2);  #预设ID
			IF PlatID>0&&ExpectTypeID<=0 THEN 
				SELECT COUNT(*) FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.PlatID=PlatID ORDER BY s.ID;
			ELSEIF ExpectTypeID>0&&PlatID<=0 THEN
				SELECT COUNT(*) FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.ExPectTypeID=ExpectTypeID ORDER BY s.ID;
			ELSEIF ExpectTypeID>0&&PlatID>0 THEN 
				SELECT COUNT(*) FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID AND s.PlatID=PlatID AND s.ExPectTypeID=ExpectTypeID ORDER BY s.ID;
			ELSE
				SELECT COUNT(*) FROM Dict_ExecuteSql s JOIN Dict_PlatForm p JOIN Dict_ExpectType t 
					WHERE s.PlatID=p.ID AND s.ExPectTypeID=t.ID ORDER BY s.ID;
			END IF;
		WHEN 3 THEN #保存校验模块
			SET PlatID=pro_split_string(`strs`,'|',1);  #平台ID
			SET ExpectTypeID=pro_split_string(`strs`,'|',2);  #预设ID
			SET Title=pro_split_string(`strs`,'|',3);  #脚本说明
			SET ExecuteSql=pro_split_string(`strs`,'|',4);  #脚本内容
			SET ExpectValue=pro_split_string(`strs`,'|',5);  #预期值
			SET AddUserID=pro_split_string(`strs`,'|',6);  #新增人ID
			SET @id=pro_split_string(`strs`,'|',7);  #校验模块ID
			IF @id>0 THEN  #修改
				UPDATE Dict_ExecuteSql s SET s.PlatID=PlatID,s.ExPectTypeID=ExpectTypeID,s.Title=Title,s.ExecuteSql=ExecuteSql,s.ExpectValue=ExpectValue WHERE s.ID=@id;
			ELSE
				INSERT INTO Dict_ExecuteSql VALUES(NULL,PlatID,ExpectTypeID,Title,ExecuteSql,true,AddUserID,NOW(),ExpectValue);
			END IF;
			SELECT '1';
		WHEN 4 THEN  #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #校验模块ID
			SET isEnable=(SELECT s.IsEnable FROM Dict_ExecuteSql s WHERE s.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN  #启用
				SET @flag=0;
			ELSE
				SET @flag=1;
			END IF;
			UPDATE Dict_ExecuteSql s SET s.IsEnable=@flag WHERE s.ID=@id;
			SELECT '1';
		WHEN 5 THEN  #通过ID查询校验模块
			SET @id=pro_split_string(`strs`,'|',1);  #校验模块ID
			SELECT * FROM Dict_ExecuteSql s WHERE s.ID=@id;
		WHEN 6 THEN #通过预测类型ID查询校验信息
			SET @id=pro_split_string(`strs`,'|',1);  #预测类型ID
			SELECT * FROM Dict_ExecuteSql s JOIN Dict_ExpectType t 
				WHERE s.ExPectTypeID=t.ID AND t.ID=@id;
	END CASE;
END;
