CREATE PROCEDURE cp_Channel_CalBack_PageRecordByPython(IN Page INT, IN PageSize INT)
  BEGIN
	DECLARE iBeginID       	INT;
	DECLARE iEndID         	INT;
	DECLARE RowCount	INT;
	
	SET iBeginID = (`Page`-1) * `PageSize`;
	SET iEndID = `PageSize`;
	SET `RowCount` = 0;
	SELECT COUNT(`ID`) INTO `RowCount`  FROM PiLing_Channel_Callback;
	IF (`RowCount` > 0)
	THEN
		SET @iID = 0;
		SELECT 	@iID:=IFNULL(@iID,0)+1 AS R_Number,	 
			 t1.`ID`
			,t1.`Channel_CaseId`
			,t1.`Channel_ModelId`
			,t1.`Request_url`	
			,t1.`Request_type`
			,t1.`Response_Param`
			,t1.`OrderID`
			,t1.`ExecutionRecordID`		
		FROM PiLing_Channel_Callback t1 
		ORDER BY R_Number DESC
		LIMIT iBeginID,iEndID;	
	END IF;	
    END;
