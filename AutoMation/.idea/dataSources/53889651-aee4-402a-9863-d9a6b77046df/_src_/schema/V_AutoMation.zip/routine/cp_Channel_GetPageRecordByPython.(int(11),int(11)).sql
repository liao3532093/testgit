CREATE PROCEDURE cp_Channel_GetPageRecordByPython(IN Page INT, IN PageSize INT)
  BEGIN
	DECLARE iBeginID       	INT;
	DECLARE iEndID         	INT;
	DECLARE RowCount	INT;
	
	SET iBeginID = (`Page`-1) * `PageSize`;
	SET iEndID = `PageSize`;
	SET `RowCount` = 0;
	SELECT COUNT(`ID`) INTO `RowCount`  FROM piling_example;
	IF (`RowCount` > 0)
	THEN
		SET @iID = 0;
		SELECT @iID:=IFNULL(@iID,0)+1 AS R_Number,
			t1.`id`
			,t1.`plat_id`
			,t1.`piling_example_title`
			,t1.`state`			
		FROM piling_example t1
		WHERE t1.`state` =1
		LIMIT iBeginID,iEndID;
	END IF;
END;
