CREATE PROCEDURE cp_Channel_GetIsExcuteRecord(IN `_exe_Value` INT)
  BEGIN
		SELECT `_exe_Value` FROM piling_exa_model WHERE isExecute=2;
    END;
