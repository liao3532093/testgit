CREATE PROCEDURE cp_ChannelReturn_Method()
  BEGIN
    
	select ID ,Title from Dict_ClassName where IsEnable = 1 ;
    END;
