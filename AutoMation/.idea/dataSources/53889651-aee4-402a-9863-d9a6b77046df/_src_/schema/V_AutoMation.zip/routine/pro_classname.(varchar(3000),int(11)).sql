CREATE PROCEDURE pro_classname(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#脚本方法
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE detail VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询脚本方法	
			SET title=pro_split_string(`strs`,'|',1);  #方法名称
			SET detail=pro_split_string(`strs`,'|',2);  #方法功能描述
			SET page=pro_split_string(`strs`,'|',3);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',4);  #多少条
			SELECT * FROM Dict_ClassName c WHERE c.Title LIKE CONCAT('%',title,'%') AND c.Detail LIKE CONCAT('%',detail,'%') 
							ORDER BY c.ID LIMIT page,pageSize;
		WHEN 2 THEN #分页查询脚本方法个数
			SET title=pro_split_string(`strs`,'|',1);  #方法名称
			SET detail=pro_split_string(`strs`,'|',2);  #方法功能描述
			SET page=pro_split_string(`strs`,'|',3);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',4);  #多少条
			SELECT COUNT(*) FROM Dict_ClassName c WHERE c.Title LIKE CONCAT('%',title,'%') AND c.Detail LIKE CONCAT('%',detail,'%') 
							ORDER BY c.ID;
		WHEN 3 THEN #保存脚本方法	
			SET title=pro_split_string(`strs`,'|',1);  #方法名称
			SET detail=pro_split_string(`strs`,'|',2);  #方法功能描述
			SET isEnable=pro_split_string(`strs`,'|',3);  #状态
			SET userId=pro_split_string(`strs`,'|',4);  #用户ID
			SET @id=pro_split_string(`strs`,'|',5);  #脚本ID
			IF @id>0 THEN #修改
				UPDATE Dict_ClassName c SET c.Title=title,c.Detail=detail,c.IsEnable=isEnable WHERE c.ID=@id;
			ELSE 
				INSERT INTO Dict_ClassName VALUES(NULL,title,detail,isEnable,userId,NOW());
			END IF;
			SELECT '1';
		WHEN 4 THEN #按ID查询脚本方法
			SET @id=pro_split_string(`strs`,'|',1);  #脚本ID
			SELECT * FROM Dict_ClassName c WHERE c.ID=@id;
		WHEN 5 THEN #查询所有脚本方法和ID
			SELECT c.ID,c.Title FROM Dict_ClassName c;
		WHEN 6 THEN #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #脚本ID
			SET isEnable=(SELECT c.IsEnable FROM Dict_ClassName c WHERE c.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN #已启用
				SET @flag=0;
			ELSE
				SET @flag=1;
			END IF;
			UPDATE Dict_ClassName c SET c.IsEnable=@flag WHERE c.ID=@id;
			SELECT '1';
	END CASE;
END;
