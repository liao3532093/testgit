CREATE PROCEDURE cp_Channel_Execute_FinalResult_AddRecord(IN `_exa_id` INT, IN `_exm_id` INT, IN `_detail` VARCHAR(256),
                                                          IN `_result` INT)
  BEGIN
    
    insert into `piling_finalResult` 
	(
		`exa_id`,
		`exm_id`,
		`detail`,
		`result`,
		`execute_time`
	)
	values
	(
		`_exa_id` 
	      ,`_exm_id` 
	      ,`_detail` 
	      ,`_result` 
	      ,CURTIME()
	 );
	 SELECT LAST_INSERT_ID();
    END;
