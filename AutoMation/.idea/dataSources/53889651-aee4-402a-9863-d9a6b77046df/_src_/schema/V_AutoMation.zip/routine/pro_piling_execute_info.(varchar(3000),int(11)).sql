CREATE PROCEDURE pro_piling_execute_info(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#渠道用例执行详情
	DECLARE platId VARCHAR(255) DEFAULT ''; #平台名称
	DECLARE oldTime VARCHAR(255) DEFAULT ''; #开始时间
	DECLARE newTime VARCHAR(255) DEFAULT ''; #结束时间
	DECLARE exaName VARCHAR(255) DEFAULT '';  #渠道用例名称
	DECLARE state INT DEFAULT 0; #状态
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN #分页查询渠道用例执行详情
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET exaName=pro_split_string(`strs`,'|',2);  #渠道用例名称
			SET state=pro_split_string(`strs`,'|',3);  #状态
			SET oldTime=pro_split_string(`strs`,'|',4);  #开始时间
			SET newTime=pro_split_string(`strs`,'|',5);  #结束时间
			SET page=pro_split_string(`strs`,'|',6);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',7);  #多少条
			IF platId>0 && state<0 THEN  #查询平台ID下的内容
				SELECT e.*,x.piling_example_title AS exaTitle,f.Title AS pTitle FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND x.plat_id=platId AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC LIMIT page,pageSize;
			ELSEIF platId<0 && state>-1 THEN #查询状态下的内容
				SELECT e.*,x.piling_example_title AS exaTitle,f.Title AS pTitle FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND e.result=state AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC LIMIT page,pageSize;
			ELSEIF platId>0 && state>-1 THEN
				SELECT e.*,x.piling_example_title AS exaTitle,f.Title AS pTitle FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND e.result=state AND x.plat_id=platId AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC LIMIT page,pageSize;
			ELSE
				SELECT e.*,x.piling_example_title AS exaTitle,f.Title AS pTitle FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN #分页查询渠道用例执行详情个数 
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET exaName=pro_split_string(`strs`,'|',2);  #渠道用例名称
			SET state=pro_split_string(`strs`,'|',3);  #状态
			SET oldTime=pro_split_string(`strs`,'|',4);  #开始时间
			SET newTime=pro_split_string(`strs`,'|',5);  #结束时间
			IF platId>0 && state<0 THEN  #查询平台ID下的内容
				SELECT COUNT(*) FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND x.plat_id=platId AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC;
			ELSEIF platId<0 && state>-1 THEN #查询状态下的内容
				SELECT COUNT(*) FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND e.result=state AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC;
			ELSEIF platId>0 && state>-1 THEN
				SELECT COUNT(*) FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND e.result=state AND x.plat_id=platId AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC;
			ELSE
				SELECT COUNT(*) FROM piling_execute_info e JOIN piling_example x JOIN Dict_PlatForm f 
				WHERE e.pil_exa_id=x.id AND x.plat_id=f.ID AND x.piling_example_title LIKE CONCAT('%',exaName,'%') 
				AND e.execute_time BETWEEN oldTime AND newTime ORDER BY e.id DESC;
			END IF;
		WHEN 3 THEN #查询用例执行详情
			SET @exaId=pro_split_string(`strs`,'|',1);  #执行渠道用例ID
			#SELECT m.id,m.piling_model_name AS tName,i.request_url AS RequestURL,i.request_params AS RequestParam,i.returnInfo AS ReturnInfo 
			#FROM piling_modelinfo i JOIN piling_model m WHERE m.id=i.exm_id AND i.exa_id=@exaId;
			SELECT m.id,m.piling_model_name AS tName,i.request_url AS RequestURL,i.request_params AS RequestParam,i.returnInfo AS ReturnInfo 
				FROM piling_modelinfo i JOIN piling_model m JOIN piling_exa_model e WHERE m.id=i.exm_id AND i.exm_id=e.piling_model_id 
				AND i.exa_id=@exaId GROUP BY i.id ORDER BY e.exe_order;
		WHEN 4 THEN #查询用例执行详情结果
			SET @exaId=pro_split_string(`strs`,'|',1);  #执行渠道用例ID
			#SELECT m.id,m.piling_model_name AS tName,u.exp_details AS tResult,r.detail AS detail,r.result AS result 
			#FROM piling_finalResult r JOIN piling_model m JOIN piling_expected_result u 
			#WHERE r.exm_id=m.id AND r.exa_id=u.exp_id AND r.exa_id=@exaId;
			SELECT t.id,m.piling_model_name AS tName,t.detail AS detail,t.result AS result,r.exp_details AS tResult 
			FROM piling_finalResult t JOIN piling_model m JOIN piling_expected_result r
			WHERE t.exm_id=r.pil_model_id AND r.pil_model_id=m.id AND t.exa_id=@exaId GROUP BY t.id;
	END CASE;
END;
