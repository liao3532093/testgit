CREATE PROCEDURE cp_Case_ExpectResult_GetRecordList(IN CaseModelID INT)
  BEGIN
	select 
		 t1.`ID`
		,t1.`CaseModelID`
		,t1.`Detail`
		,t1.`SqlID`
		,t2.`PlatID`
		,t2.`ExpectTypeID`
		,t2.`ExecuteSql`
		,t2.`ExpectValue`
		
	from Case_ExpectResult t1  
	JOIN Dict_ExecuteSql t2 On t2.`ID` = t1.`SqlID`
	where t1.`CaseModelID` = `CaseModelID` AND t1.`IsEnable` = 1
	order by t1.`OrderNum` asc;
			
END;
