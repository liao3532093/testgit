CREATE PROCEDURE cp_Channel_Previous_Step(IN piling_exa_id INT)
  BEGIN
	select * from piling_exa_model t1 join piling_model t2  
	where t1.piling_exa_id =`piling_exa_id` and exe_order = 2 and isExecute = 0  and t2.modelType =2 and t2.id =t1.piling_model_id;
    END;
