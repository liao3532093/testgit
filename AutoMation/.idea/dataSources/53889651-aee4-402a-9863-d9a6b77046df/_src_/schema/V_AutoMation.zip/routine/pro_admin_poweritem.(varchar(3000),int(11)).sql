CREATE PROCEDURE pro_admin_poweritem(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#权限关键字
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	
	CASE `index`
		WHEN 1 THEN #保存权限关键字
			SET @parentId=pro_split_string(`strs`,'|',1);  #小类别权限ID
			SET @keystr=pro_split_string(`strs`,'|',2);  #关键词
			SET @title=pro_split_string(`strs`,'|',3);  #权限名称
			SET @id=pro_split_string(`strs`,'|',4);  #权限关键字ID
			IF @id>0 THEN #修改
				SET @count=(SELECT COUNT(*) FROM Admin_PowerItem i WHERE i.Keywords=@keystr AND i.ParentClassID=@parentId);
				SET @kys=(SELECT i.Keywords FROM Admin_PowerItem i WHERE i.Keywords=@keystr AND i.ParentClassID=@parentId);
				IF @count<=0 || @kys=@keystr THEN
					UPDATE Admin_PowerItem i SET i.Keywords=@keystr,i.ParentClassID=@parentId,i.Title=@title WHERE i.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
			ELSE #添加
				SET @count=(SELECT COUNT(*) FROM Admin_PowerItem i WHERE i.Keywords=@keystr AND i.ParentClassID=@parentId);
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO Admin_PowerItem VALUES(NULL,@parentId,@keystr,@title);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询权限关键字
			SET @parentId=pro_split_string(`strs`,'|',1);  #小类别权限ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT * FROM Admin_PowerItem i WHERE i.ParentClassID=@parentId ORDER BY i.ID LIMIT page,pageSize;
		WHEN 3 THEN #分页查询权限关键字个数 
			SET @parentId=pro_split_string(`strs`,'|',1);  #小类别权限ID
			SELECT COUNT(*) FROM Admin_PowerItem i WHERE i.ParentClassID=@parentId ORDER BY i.ID;
		WHEN 4 THEN #按ID查询权限关键字
			SET @id=pro_split_string(`strs`,'|',1);  #权限关键字ID
			SELECT * FROM Admin_PowerItem i WHERE i.ID=@id;
	END CASE;
END;
