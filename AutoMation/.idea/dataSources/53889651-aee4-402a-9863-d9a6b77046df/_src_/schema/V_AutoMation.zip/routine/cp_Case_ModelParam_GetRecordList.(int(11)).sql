CREATE PROCEDURE cp_Case_ModelParam_GetRecordList(IN CaseModelID INT)
  BEGIN
	select 
		t1.ID
		,t3.`Title` as `ParamName`
		,t1.`Value` as `ParamValue`
	from Case_ModelParam t1 
	Join Case_Model t2 		On t2.`ID` = t1.`CaseModelID` and t2.`IsEnable` = 1
	join Dict_ModelParam t3 	on t3.`ID` = t1.`ParamID` and t3.`Model_ID` = t2.`ModelID` and t3.`IsEnable` = 1
	where t1.`CaseModelID` = `CaseModelID` and t2.`IsEnable` = 1;
    END;
