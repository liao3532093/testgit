CREATE PROCEDURE cp_Channel_Get_Return_Orderid(IN `_exa_id` INT)
  BEGIN
	/*select 
		t4.`id`,
		t1.piling_exa_id,
		t1.piling_model_id,
		t3.`request_params`,
		t2.request_url,
		t2.request_type,
		t2.modelType
	from piling_exa_model t1 join piling_model t2  join piling_modelinfo t3  join piling_execute_info t4
	on t2.`id` = t1.`piling_model_id` and t3.exm_id = t1.piling_exa_id and t3.exa_id = t4.`id`
	
	where t1.exe_order = (`_exe_order`)-1 and t1.isExecute = 0  and t3.exa_id = t4.`id`
	order by t4.`id` DESC;*/
	SELECT  t3.`id`,
		t2.`request_params` ,
		t1.`piling_exa_id` , 
		t1.`piling_model_id` 
		
	FROM piling_exa_model t1 join piling_modelinfo t2  on t2.`exm_id` =  t1.`piling_model_id`
	join piling_execute_info t3  on t3.`id` =  t2.`exa_id` 
	where  t1.`piling_exa_id` =  t3.pil_exa_id   and t3.`id` = `_exa_id` and t1.`exe_order` =1 ;
	 
    END;
