CREATE PROCEDURE pro_execute_update_tig(IN id INT, IN result INT)
  BEGIN
	#统计数据修改触发器
	DECLARE eid INT DEFAULT 0;
	DECLARE res INT DEFAULT 0;
	DECLARE success INT DEFAULT 0;
	DECLARE fail INT DEFAULT 0;
	DECLARE error INT DEFAULT 0;

	SET @date=DATE_FORMAT(NOW(),'%Y-%m-%d');
	SET @cid=(SELECT e.CaseID FROM Execute_Info e WHERE DATE_FORMAT(e.AddTime,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') ORDER BY e.AddTime DESC LIMIT 1);
	SET @pid=(SELECT c.PlatID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=@cid LIMIT 1); #平台ID
	SET @iid=(SELECT c.InterfaceID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=@cid LIMIT 1); #接口ID
	SET @count=(SELECT COUNT(*) FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
	SET error=(SELECT COUNT(e.Result) AS error FROM Execute_Info e WHERE e.Result=1 AND DATE_FORMAT(e.AddTime,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') 
	GROUP BY DATE_FORMAT(e.AddTime,'%Y-%m-%d'));
	SET success=(SELECT COUNT(e.Result) AS success FROM Execute_Info e WHERE e.Result=2 AND DATE_FORMAT(e.AddTime,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') 
	GROUP BY DATE_FORMAT(e.AddTime,'%Y-%m-%d'));
	SET fail=(SELECT COUNT(e.Result) AS fail FROM Execute_Info e WHERE e.Result=3 AND DATE_FORMAT(e.AddTime,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') 
	GROUP BY DATE_FORMAT(e.AddTime,'%Y-%m-%d'));
	IF error IS NULL THEN
		SET error=0;
	END IF;
	IF success IS NULL THEN
		SET success=0;
	END IF;
	IF fail IS NULL THEN
		SET fail=0;
	END IF;
	IF @pid IS NULL || @iid IS NULL THEN
		SELECT '';
	ELSE
		IF @count>0 THEN #修改
			SET @id=(SELECT e.ID FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
			IF error=0&&success=0&&fail=0 THEN
				SELECT '';
			ELSE
				UPDATE Stat_ExecuteDay s SET s.FailNum=error,s.ErrorNum=fail,s.SuccessNum=success WHERE s.ID=@id;
			END IF;
		ELSE  #添加
			IF error=0&&success=0&&fail=0 THEN
				SELECT '';
			ELSE
				INSERT INTO Stat_ExecuteDay VALUES(NULL,success,error,DATE_FORMAT(NOW(),'%Y-%m-%d'),NOW(),@pid,@iid,fail);
			END IF;
		END IF;
	END IF;
END;
