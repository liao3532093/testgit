CREATE PROCEDURE pro_system_log(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#系统日志
	DECLARE uid INT DEFAULT 0;
	DECLARE info VARCHAR(255) DEFAULT '';
	DECLARE logId INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	DECLARE inDate VARCHAR(255) DEFAULT '';
	DECLARE outDate VARCHAR(255) DEFAULT '';

	CASE `index`
		WHEN 1 THEN  #保存日志信息
			SET uid=pro_split_string(`strs`,'|',1);  #用户ID
			SET info=pro_split_string(`strs`,'|',2);  #详情
			SET @logKey=pro_split_string(`strs`,'|',3);  #日关键字
			SET logId=(SELECT l.ID FROM Log_Type l WHERE l.LogKey=@logKey);
			INSERT INTO System_Log VALUES(NULL,uid,info,logId,NOW());
			SELECT '1';
		WHEN 2 THEN #查询日志
			SET @showName=pro_split_string(`strs`,'|',1);  #用户名称
			SET info=pro_split_string(`strs`,'|',2);  #详情
			SET logId=pro_split_string(`strs`,'|',3);  #日志类型
			SET inDate=pro_split_string(`strs`,'|',4);  #开始日期
			SET outDate=pro_split_string(`strs`,'|',5);  #结束日期
			SET page=pro_split_string(`strs`,'|',6);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',7);  #多少条
			IF logId>0 THEN
				SELECT l.ID,u.Account AS showName,u.LastLoginIP AS ipConfig,l.info,g.Title AS logName,l.AddTime FROM System_Log l JOIN Admin_User u JOIN Log_Type g WHERE l.userId=u.ID AND g.ID=l.logId 
				AND l.info LIKE CONCAT('%',info,'%') AND u.ShowName LIKE CONCAT('%',@showName,'%') AND g.ID=logId AND l.AddTime BETWEEN inDate AND outDate ORDER BY l.ID DESC 
				LIMIT page,pageSize;
			ELSE
				SELECT l.ID,u.Account AS showName,u.LastLoginIP AS ipConfig,l.info,g.Title AS logName,l.AddTime FROM System_Log l JOIN Admin_User u JOIN Log_Type g WHERE l.userId=u.ID AND g.ID=l.logId 
				AND l.info LIKE CONCAT('%',info,'%') AND u.ShowName LIKE CONCAT('%',@showName,'%') AND l.AddTime BETWEEN inDate AND outDate ORDER BY l.ID DESC 
				LIMIT page,pageSize;
			END IF;
		WHEN 3 THEN #查询日志个数
			SET @showName=pro_split_string(`strs`,'|',1);  #用户名称
			SET info=pro_split_string(`strs`,'|',2);  #详情
			SET logId=pro_split_string(`strs`,'|',3);  #日志类型
			SET inDate=pro_split_string(`strs`,'|',4);  #开始日期
			SET outDate=pro_split_string(`strs`,'|',5);  #结束日期
			IF logId>0 THEN
				SELECT COUNT(*) FROM System_Log l JOIN Admin_User u JOIN Log_Type g WHERE l.userId=u.ID AND g.ID=l.logId 
				AND l.info LIKE CONCAT('%',info,'%') AND u.ShowName LIKE CONCAT('%',@showName,'%') AND g.ID=logId AND l.AddTime BETWEEN inDate AND outDate ORDER BY l.ID DESC;
			ELSE
				SELECT COUNT(*) FROM System_Log l JOIN Admin_User u JOIN Log_Type g WHERE l.userId=u.ID AND g.ID=l.logId 
				AND l.info LIKE CONCAT('%',info,'%') AND u.ShowName LIKE CONCAT('%',@showName,'%') AND l.AddTime BETWEEN inDate AND outDate ORDER BY l.ID DESC;
			END IF;
	END CASE;
END;
