CREATE PROCEDURE cp_Channel_GetCallBack_Prediction_Result(IN `_ID` INT)
  BEGIN
    
	SELECT 
	t1.ID ,
	t1.Callback_table_ID ,
	t1.Expected_Description ,
	t1.Channel_ModuleID ,
	t1.ExpectTypeID ,
	t1.Sql_ID ,
	t1.ExpectValue,
	t3.ExecuteSql
	FROM PiLing_Channel_expected_Result t1 
	JOIN PiLing_Channel_Callback t2 ON  t1.`Callback_table_ID` = t2.ID
	JOIN Dict_ExecuteSql t3 ON t3.ID=t1.Sql_ID
	WHERE t1.`Callback_table_ID` = `_ID`;
    END;
