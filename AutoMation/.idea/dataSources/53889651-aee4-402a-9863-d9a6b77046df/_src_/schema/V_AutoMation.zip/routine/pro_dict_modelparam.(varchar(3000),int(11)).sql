CREATE PROCEDURE pro_dict_modelparam(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#模块参数
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE val VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询所有模块参数
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT * FROM Dict_ModelParam m WHERE m.Model_ID=@modelID ORDER BY m.ID LIMIT page,pageSize;
		WHEN 2 THEN #分页查询所有模块参数个数 
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SELECT COUNT(*) FROM Dict_ModelParam m WHERE m.Model_ID=@modelID ORDER BY m.ID;
		WHEN 3 THEN  #保存模块参数
			SET title=pro_split_string(`strs`,'|',1);  #模块参数名称
			SET val=pro_split_string(`strs`,'|',2);  #参数值，参数方法名
			SET @modelID=pro_split_string(`strs`,'|',3);  #所属模块ID
			SET @valueType=pro_split_string(`strs`,'|',4);  #参数类型（1=值类型；2=方法类型）
			SET @id=pro_split_string(`strs`,'|',5);  #模块参数ID
			SET userId=(SELECT r.AddUserID FROM Dict_RequestModel r WHERE r.ID=@modelID);
			IF @id>0 THEN #修改
				UPDATE Dict_ModelParam m SET m.Title=title,m.`Value`=val,m.ValueType=@valueType WHERE m.ID=@id;
			ELSE 
				INSERT INTO Dict_ModelParam VALUES(NULL,title,val,@modelID,true,userId,NOW(),@valueType);
			END IF;
			SELECT '1';
		WHEN 4 THEN  #启用禁用模块参数
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SET @id=pro_split_string(`strs`,'|',2);  #模块参数ID
			SET @flag=(SELECT m.IsEnable FROM Dict_ModelParam m WHERE m.Model_ID=@modelID AND m.ID=@id);
			IF @flag>0 THEN  #已经启用
				UPDATE Dict_ModelParam m SET m.IsEnable=false WHERE m.Model_ID=@modelID AND m.ID=@id;
			ELSE
				UPDATE Dict_ModelParam m SET m.IsEnable=true WHERE m.Model_ID=@modelID AND m.ID=@id;
			END IF;
			SELECT '1';
		WHEN 5 THEN #通过ID查询模块参数
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SET @id=pro_split_string(`strs`,'|',2);  #模块参数ID
			SELECT * FROM Dict_ModelParam m WHERE m.Model_ID=@modelID AND m.ID=@id;
		WHEN 6 THEN 
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SELECT m.ID FROM Dict_ModelParam m WHERE m.Model_ID=@modelID ORDER BY m.ID;
		WHEN 7 THEN #通过请求模块配置ID查询
			SET @modelID=pro_split_string(`strs`,'|',1);  #所属模块ID
			SELECT * FROM Dict_ModelParam m WHERE m.Model_ID=@modelID ORDER BY m.ID;
		WHEN 8 THEN #统一配置模块参数
			SET @id=pro_split_string(`strs`,'|',1);  #模块参数
			SET @val=(SELECT m.`Value` FROM Dict_ModelParam m WHERE m.ID=@id);
			UPDATE Case_ModelParam m SET m.`Value`=@val WHERE m.ParamID=@id;
			SELECT '1';
	END CASE;
END;
