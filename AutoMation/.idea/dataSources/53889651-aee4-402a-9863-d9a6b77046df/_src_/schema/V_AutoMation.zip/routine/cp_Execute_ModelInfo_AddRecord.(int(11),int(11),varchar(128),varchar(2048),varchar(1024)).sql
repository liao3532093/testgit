CREATE PROCEDURE cp_Execute_ModelInfo_AddRecord(IN `_ExecuteID`  INT, IN `_CaseModelID` INT,
                                                IN `_RequestURL` VARCHAR(128), IN `_RequestParam` VARCHAR(2048),
                                                IN `_ReturnInfo` VARCHAR(1024))
  BEGIN
	insert into Execute_ModelInfo(
			`ExecuteID`,
			`CaseModelID`,
			`RequestURL` ,
			`RequestParam` ,
			`ReturnInfo` )
	values(
			`_ExecuteID` ,
			`_CaseModelID` ,
			`_RequestURL` ,
			`_RequestParam` ,
			`_ReturnInfo` );
	SELECT	@@IDENTITY;
    END;
