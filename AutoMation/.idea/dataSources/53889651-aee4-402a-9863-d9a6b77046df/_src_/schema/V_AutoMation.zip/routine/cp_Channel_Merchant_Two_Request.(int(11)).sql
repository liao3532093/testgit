CREATE PROCEDURE cp_Channel_Merchant_Two_Request(IN `_CaseID` INT)
  BEGIN
	sELECT   
	t1.id,
	t1.piling_model_id, 
	t1.piling_exa_id , 
	t2.request_url, 
	t2.request_type , 
	t2.response_item,
	t2.modelType,
	t1.exe_order,
	t1.isExecute
	
 FROM piling_exa_model t1 JOIN piling_model t2  join piling_example t3 
    WHERE t2.modelType = 1 AND t1.exe_order >1 AND t2.state = 1  and t3.state = 1 AND t3.id =  `_CaseID`  
    AND t2.id = t1.piling_model_id AND t3.id = t1.piling_exa_id;
    #SELECT * FROM piling_example t1
	#JOIN piling_exa_model t2 ON t2.piling_exa_id=t1.id
	#JOIN piling_model t3 ON t3.id=t2.piling_model_id
	#WHERE t3.modelType=1
	#AND t1.id=1
	#AND t2.exe_order>1    
	#AND t1.state = 1
	    
    END;
