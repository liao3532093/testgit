CREATE PROCEDURE pro_admin_powerclass(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#权限大类别
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	
	CASE `index`
		WHEN 1 THEN #保存大类别权限
			SET @title=pro_split_string(`strs`,'|',1);  #大类别权限名称
			SET @isLock=pro_split_string(`strs`,'|',2);  #是否锁定
			SET @orderNo=pro_split_string(`strs`,'|',3);  #排序（从小到大排序）
			SET @id=pro_split_string(`strs`,'|',4);  #大类别权限ID
			SET @flag=false;
			IF @isLock>0 THEN
				SET @flag=true;
			ELSE
				SET @flag=false;
			END IF;
			IF @id>0 THEN #修改
				SET @num=(SELECT c.OrderNo FROM Admin_PowerClass c WHERE c.ID=@id);
				SET @count=(SELECT COUNT(*) FROM Admin_PowerClass c WHERE c.OrderNo=@orderNo);
				IF @count<=0 || @orderNo=@num THEN
					UPDATE Admin_PowerClass p SET p.Title=@title,p.IsLock=@flag,p.OrderNo=@orderNo WHERE p.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
			ELSE
				SET @count=(SELECT COUNT(*) FROM Admin_PowerClass c WHERE c.OrderNo=@orderNo);
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO Admin_PowerClass VALUES(NULL,@title,@flag,@orderNo);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询大类别权限
			SET page=pro_split_string(`strs`,'|',1);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',2);  #多少条
			SELECT * FROM Admin_PowerClass c ORDER BY c.OrderNo LIMIT page,pageSize;
		WHEN 3 THEN #分页查询大类别权限个数
			SELECT COUNT(*) FROM Admin_PowerClass c ORDER BY c.OrderNo;
		WHEN 4 THEN #按ID查询大类别权限
			SET @id=pro_split_string(`strs`,'|',1);  #大类别权限ID
			SELECT * FROM Admin_PowerClass c WHERE c.ID=@id;
		WHEN 5 THEN #查询没有禁用的大类别权限
			SELECT * FROM Admin_PowerClass c WHERE c.IsLock=false;
	END CASE;
END;
