CREATE PROCEDURE cp_Channel_Execute_ModelInfo_AddRecord(IN `_exa_id`      INT, IN `_exm_id` INT,
                                                        IN `_request_url` VARCHAR(128), IN `_request_params` LONGTEXT,
                                                        IN `_returnInfo`  LONGTEXT)
  BEGIN
		insert into piling_modelinfo(
			`exa_id`,
			`exm_id`,
			`request_url` ,
			`request_params` ,
			`returnInfo` )
	values(
			`_exa_id`,
			`_exm_id`,
			`_request_url` ,
			`_request_params` ,
			`_returnInfo` );
	SELECT	@@IDENTITY;
    END;
