CREATE PROCEDURE cp_Execute_FinalResult_AddRecord(IN `_ExecID` INT, IN `_ExecModelID` INT, IN `_ExpectID` INT,
                                                  IN `_Detail` VARCHAR(256), IN `_Result` INT)
  BEGIN
    
	insert into `Execute_FinalResult` 
	(
		`ExecID`,
		`ExecModelID`,
		`ExpectID`,
		`Detail`,
		`Result`,
		`Addtime`
	)
	values
	(
		`_ExecID` 
	      ,`_ExecModelID` 
	      ,`_ExpectID` 
	      ,`_Detail` 
	      ,`_Result` 
	      ,CURTIME());
	   SELECT  @@IDENTITY,`_ExecID` ,`_ExecModelID` ,`_ExpectID` ,`_Detail`,`_Result` ;
    
    END;
