CREATE PROCEDURE pro_piling_exa_model(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#渠道用例模块配置
	DECLARE modelId INT DEFAULT 0; #渠道模块ID
	DECLARE exaId INT DEFAULT 0; #渠道用例ID
	DECLARE orderId INT DEFAULT 0; #顺序
	DECLARE state INT DEFAULT 1; #状态
	DECLARE val VARCHAR(3000) DEFAULT '';  #参数
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN #保存渠道用例模块
			SET modelId=pro_split_string(`strs`,'|',1);  #渠道模块ID
			SET exaId=pro_split_string(`strs`,'|',2);  #渠道用例ID
			SET val=pro_split_string(`strs`,'|',3);  #参数
			SET orderId=pro_split_string(`strs`,'|',4);  #顺序
			SET @id=pro_split_string(`strs`,'|',5);  #ID
			SET @count=(SELECT COUNT(*) FROM piling_exa_model p WHERE p.exe_order=orderId AND p.piling_exa_id=exaId);
			IF @id>0 THEN #修改	
				SET @old=(SELECT p.exe_order FROM piling_exa_model p WHERE p.id=@id);
				IF @count>0 && @old!=orderId THEN
					SELECT '-1';
				ELSE
					UPDATE piling_exa_model p SET p.piling_model_id=modelId,p.piling_exa_id=exaId,p.exe_order=orderId,
						p.exa_value=val WHERE p.id=@id;
					SELECT '1';
				END IF;
			ELSE #添加
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO piling_exa_model VALUES(NULL,modelId,exaId,val,orderId,state,NOW(),0);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询渠道用例模块
			SET exaId=pro_split_string(`strs`,'|',1);  #渠道用例ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT p.*,m.piling_model_name AS modelName FROM piling_exa_model p JOIN piling_model m 
				WHERE p.piling_model_id=m.id AND p.piling_exa_id=exaId ORDER BY p.exe_order LIMIT page,pageSize;
		WHEN 3 THEN #分页查询渠道用例模块个数 
			SET exaId=pro_split_string(`strs`,'|',1);  #渠道用例ID
			SELECT COUNT(*) FROM piling_exa_model p JOIN piling_model m WHERE p.piling_model_id=m.id AND p.piling_exa_id=exaId ORDER BY p.exe_order;
		WHEN 4 THEN #禁用和启用
			SET exaId=pro_split_string(`strs`,'|',1);  #渠道用例ID
			SET @id=pro_split_string(`strs`,'|',2);  #ID
			SET @len=0;
			SET state=(SELECT p.state FROM piling_exa_model p WHERE p.id=@id AND p.piling_exa_id=exaId);
			IF state=0 THEN
				SET @len=1;
			ELSE
				SET @len=0;
			END IF;
			UPDATE piling_exa_model p SET p.state=@len WHERE p.id=@id AND p.piling_exa_id=exaId;
			SELECT '1';
		WHEN 5 THEN #按ID查询渠道用例模块
			SET exaId=pro_split_string(`strs`,'|',1);  #渠道用例ID
			SET @id=pro_split_string(`strs`,'|',2);  #ID
			SELECT * FROM piling_exa_model p WHERE p.piling_exa_id=exaId AND p.id=@id;
		WHEN 6 THEN #查询用例模块配置下的预期结果表数据
			SET @id=pro_split_string(`strs`,'|',1);  #渠道用例模块配置ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT m.*,r.exp_details AS details,r.ExpectValue AS expectValue,r.piling_exp_res_id AS resultId FROM piling_exa_model m JOIN piling_exa_model_result r
					WHERE m.id=r.piling_exa_model_id AND m.id=@id LIMIT page,pageSize;
		WHEN 7 THEN #查询用例模块配置下的默认预期结果
			SET @id=pro_split_string(`strs`,'|',1);  #渠道用例模块配置ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT m.*,r.exp_details AS details,r.ExpectValue AS expectValue,r.id AS resultId FROM piling_exa_model m JOIN piling_expected_result r 
					WHERE m.piling_model_id=r.pil_model_id AND r.state=1 AND m.id=@id LIMIT page,pageSize;
		WHEN 8 THEN #修改预期结果
			SET @id=pro_split_string(`strs`,'|',1);  #渠道用例模块配置ID
			SET @resultId=pro_split_string(`strs`,'|',2);  #渠道模块预期结果ID
			SET @details=pro_split_string(`strs`,'|',3);  #预期说明
			SET @val=pro_split_string(`strs`,'|',4);  #预期值
			SET @count=(SELECT COUNT(*) FROM piling_exa_model_result r WHERE r.piling_exa_model_id=@id AND r.piling_exp_res_id=@resultId);
			IF @count>0 THEN
				UPDATE piling_exa_model_result r SET r.exp_details=@details,r.ExpectValue=@val 
					WHERE r.piling_exa_model_id=@id AND r.piling_exp_res_id=@resultId;
			ELSE
				SET @model_id=(SELECT m.piling_model_id FROM piling_exa_model m WHERE m.id=@id);
				INSERT INTO piling_exa_model_result VALUES(NULL,@model_id,@id,@resultId,@details,@val);
			END IF;
			SELECT '1';
	END CASE;
END;
