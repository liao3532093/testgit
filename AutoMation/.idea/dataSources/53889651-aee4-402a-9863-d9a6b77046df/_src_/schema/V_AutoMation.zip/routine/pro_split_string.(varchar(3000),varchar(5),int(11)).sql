CREATE FUNCTION pro_split_string(strs VARCHAR(3000), split VARCHAR(5), count INT)
  RETURNS VARCHAR(3000)
  BEGIN
	#获取给定字符串的分隔数
	DECLARE result VARCHAR(3000) DEFAULT '';
	SET result=REVERSE(SUBSTRING_INDEX(REVERSE(SUBSTRING_INDEX(`strs`,`split`,`count`)),`split`,1));
	RETURN result;
END;
