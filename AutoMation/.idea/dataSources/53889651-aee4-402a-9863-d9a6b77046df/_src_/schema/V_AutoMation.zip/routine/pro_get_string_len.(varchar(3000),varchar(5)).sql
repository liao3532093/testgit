CREATE FUNCTION pro_get_string_len(strs VARCHAR(3000), split VARCHAR(5))
  RETURNS INT
  BEGIN
	#Routine body goes here...
	RETURN 1+(LENGTH(`strs`)-LENGTH(REPLACE(`strs`,`split`,'')));
END;
