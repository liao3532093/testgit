CREATE PROCEDURE pro_platform_interface(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#平台接口
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #保存平台接口
			SET @dId=pro_split_string(`strs`,'|',1);  #接口ID
			SET title=pro_split_string(`strs`,'|',2);  #接口名称
			SET @pId=pro_split_string(`strs`,'|',3);  #平台ID
			SET isEnable=pro_split_string(`strs`,'|',4);  #是否可用
			SET userId=pro_split_string(`strs`,'|',5);  #新增人ID
			SET @flag=false;
			IF isEnable>0 THEN
				SET @flag=true;
			ELSE
				SET @flag=false;
			END IF;
			IF @dId>0 THEN  #修改
				SET @oldName=(SELECT i.Title FROM Dict_Interface i WHERE i.ID=@dId);   #取得旧的名称
				UPDATE Dict_Interface i SET i.Title=title,i.PlatID=@pId,i.IsEnable=isEnable WHERE i.ID=@dId;
				SELECT '1';
			ELSE  #添加
				SET @count=(SELECT COUNT(*) FROM Dict_Interface i JOIN Dict_PlatForm d WHERE i.Title=title AND i.PlatID=d.ID AND i.PlatID=@pId);
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO Dict_Interface VALUES(NULL,title,@pId,@flag,userId,NOW());
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN  #分页查询平台接口
			SET page=pro_split_string(`strs`,'|',1);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',2);  #多少条
			SET @platId=pro_split_string(`strs`,'|',3);  #平台ID
			SET title=pro_split_string(`strs`,'|',4);  #接口名称
			IF title='-1' THEN
				SET title='';
			END IF;
			IF @platId>-1 THEN
				SELECT i.ID,i.Title,i.PlatID,i.IsEnable,i.AddUserID,i.AddTime,p.Title AS platName FROM Dict_PlatForm p JOIN Dict_Interface i 
					WHERE p.ID=i.PlatID AND p.ID=@platId AND i.Title LIKE CONCAT('%',title,'%') ORDER BY i.ID LIMIT page,pageSize;
			ELSE
				SELECT i.ID,i.Title,i.PlatID,i.IsEnable,i.AddUserID,i.AddTime,p.Title AS platName FROM Dict_PlatForm p JOIN Dict_Interface i 
					WHERE p.ID=i.PlatID AND i.Title LIKE CONCAT('%',title,'%') ORDER BY i.ID LIMIT page,pageSize;
			END IF;
		WHEN 3 THEN  #查询接口个数 
			SET page=pro_split_string(`strs`,'|',1);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',2);  #多少条
			SET @platId=pro_split_string(`strs`,'|',3);  #平台ID
			SET title=pro_split_string(`strs`,'|',4);  #接口名称
			IF title='-1' THEN
				SET title='';
			END IF;
			IF @platId>-1 THEN
				SELECT COUNT(*) FROM Dict_PlatForm p JOIN Dict_Interface i 
					WHERE p.ID=i.PlatID AND p.ID=@platId AND i.Title LIKE CONCAT('%',title,'%') ORDER BY i.ID;
			ELSE
				SELECT COUNT(*) FROM Dict_PlatForm p JOIN Dict_Interface i 
					WHERE p.ID=i.PlatID AND i.Title LIKE CONCAT('%',title,'%') ORDER BY i.ID;
			END IF;
		WHEN 4 THEN #按ID查询接口
			SET @id=pro_split_string(`strs`,'|',1);  #接口ID
			SELECT * FROM Dict_Interface i WHERE i.ID=@id;
		WHEN 5 THEN #查询接口过滤禁用
			SET isEnable=pro_split_string(`strs`,'|',1);  #是否禁用
			IF isEnable>0 THEN
				SELECT i.ID,i.Title FROM Dict_Interface i WHERE i.IsEnable=isEnable;
			ELSE
				SELECT i.ID,i.Title FROM Dict_Interface i;
			END IF;
		WHEN 6 THEN #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #接口ID
			SET isEnable=(SELECT i.IsEnable FROM Dict_Interface i WHERE i.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN	#已启用	
				SET @flag=0;
			ELSE
        SET @flag=1;
			END IF;
			UPDATE Dict_Interface i SET i.IsEnable=@flag WHERE i.ID=@id;
			SELECT '1';
	END CASE;
END;
