CREATE PROCEDURE cp_Channel_updateRecord(IN id INT, IN piling_exa_id INT, IN `_Isexcute` INT)
  BEGIN
	#设置当前启用的用例所有模块为 未执行，怕数据混乱
	UPDATE piling_exa_model t1 SET isExecute = 0 WHERE t1.state = 1 and t1.`piling_exa_id` = `piling_exa_id` ;
	
	SET @StepNum = (SELECT t1.`exe_order` FROM piling_exa_model t1 WHERE t1.`id` = `id`);	
	SET @StepNum = @StepNum + 1;
	
	#设置下一个模块状态为 执行中
	UPDATE piling_exa_model t1 SET isExecute = `_Isexcute` WHERE t1.state = 1 AND exe_order = @StepNum AND t1.`piling_exa_id` = `piling_exa_id` ;
	
	
END;
