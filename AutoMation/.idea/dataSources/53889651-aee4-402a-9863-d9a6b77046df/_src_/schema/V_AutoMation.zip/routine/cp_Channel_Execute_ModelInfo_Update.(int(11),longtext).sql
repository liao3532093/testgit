CREATE PROCEDURE cp_Channel_Execute_ModelInfo_Update(IN `_ExecuteInfoID` INT, IN `_returnInfo` LONGTEXT)
  BEGIN
    
	update piling_modelinfo set returnInfo = `_returnInfo` where id = `_ExecuteInfoID` ;
    
    END;
