CREATE PROCEDURE pro_test(IN strs VARCHAR(3000))
  BEGIN
	#Routine body goes here...
	
	SET @res=' * FROM piling_exa_model m WHERE m.id=1';
	SELECT @res;
END;
