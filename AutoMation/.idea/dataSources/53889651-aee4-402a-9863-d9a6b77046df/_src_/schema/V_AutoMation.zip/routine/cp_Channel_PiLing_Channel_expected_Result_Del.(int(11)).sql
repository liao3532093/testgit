CREATE PROCEDURE cp_Channel_PiLing_Channel_expected_Result_Del(IN `_ID` INT)
  BEGIN
		delete from PiLing_Channel_expected_Result where ID =`_ID`;
    END;
