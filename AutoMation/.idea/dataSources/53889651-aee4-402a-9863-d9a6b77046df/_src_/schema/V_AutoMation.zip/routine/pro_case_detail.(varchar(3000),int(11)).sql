CREATE PROCEDURE pro_case_detail(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用例详情
	DECLARE platID INT DEFAULT 0;
	DECLARE interfaceID INT DEFAULT 0;
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE detail VARCHAR(255) DEFAULT '';
	DECLARE isEnable INT DEFAULT 0;
	DECLARE userId INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询用例详情
			SET platID=pro_split_string(`strs`,'|',1);  #所属平台ID
			SET interfaceID=pro_split_string(`strs`,'|',2);  #所属接口ID
			SET title=pro_split_string(`strs`,'|',3);  #用例标题
			SET page=pro_split_string(`strs`,'|',4);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',5);  #多少条
			IF platID>0&&interfaceID<=0 THEN
				SELECT d.ID,d.PlatID,d.InterfaceID,d.Title,d.Detail,d.IsEnable,d.AddUserID,d.AddTiime,p.Title AS platName,i.Title AS interName 
					FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.PlatID=platID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID LIMIT page,pageSize;
			ELSEIF interfaceID>0&&platID<=0 THEN 
				SELECT d.ID,d.PlatID,d.InterfaceID,d.Title,d.Detail,d.IsEnable,d.AddUserID,d.AddTiime,p.Title AS platName,i.Title AS interName 
					FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.InterfaceID=interfaceID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID LIMIT page,pageSize;
			ELSEIF platID>0&&interfaceID>0 THEN 
				SELECT d.ID,d.PlatID,d.InterfaceID,d.Title,d.Detail,d.IsEnable,d.AddUserID,d.AddTiime,p.Title AS platName,i.Title AS interName 
					FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.PlatID=platID 
					AND d.InterfaceID=interfaceID AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID LIMIT page,pageSize;
			ELSE
				SELECT d.ID,d.PlatID,d.InterfaceID,d.Title,d.Detail,d.IsEnable,d.AddUserID,d.AddTiime,p.Title AS platName,i.Title AS interName 
					FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN  #分页查询用例详情个数
			SET platID=pro_split_string(`strs`,'|',1);  #所属平台ID
			SET interfaceID=pro_split_string(`strs`,'|',2);  #所属接口ID
			SET title=pro_split_string(`strs`,'|',3);  #用例标题
			IF platID>0&&interfaceID<=0 THEN
				SELECT COUNT(*) FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.PlatID=platID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID;
			ELSEIF interfaceID>0&&platID<=0 THEN 
				SELECT COUNT(*) FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.InterfaceID=interfaceID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID;
			ELSEIF platID>0&&interfaceID>0 THEN 
				SELECT COUNT(*) FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.PlatID=platID 
					AND d.InterfaceID=interfaceID AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID;
			ELSE
				SELECT COUNT(*) FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID 
					AND d.Title LIKE CONCAT('%',title,'%') ORDER BY d.ID;
			END IF;
		WHEN 3 THEN  #保存用例详情
			SET platID=pro_split_string(`strs`,'|',1);  #所属平台ID
			SET interfaceID=pro_split_string(`strs`,'|',2);  #所属接口ID
			SET title=pro_split_string(`strs`,'|',3);  #用例标题
			SET detail=pro_split_string(`strs`,'|',4);  #用例描述
			SET isEnable=pro_split_string(`strs`,'|',5);  #是否可用
			SET userId=pro_split_string(`strs`,'|',6);  #新增人用户ID
			SET @id=pro_split_string(`strs`,'|',7);  #用例详情ID
			IF @id>0 THEN #修改	
				UPDATE Case_Detail c SET c.PlatID=platID,c.InterfaceID=interfaceID,c.Title=title,c.Detail=detail,c.IsEnable=isEnable WHERE c.ID=@id;
			ELSE
				INSERT INTO Case_Detail VALUES(NULL,platID,interfaceID,title,detail,isEnable,userId,NOW());
			END IF;
			SELECT '1';
		WHEN 4 THEN  #通过ID查询用例详情
			SET @id=pro_split_string(`strs`,'|',1);  #用例详情ID
			SELECT d.ID,d.PlatID,d.InterfaceID,d.Title,d.Detail,d.IsEnable,d.AddUserID,d.AddTiime,p.Title AS platName,i.Title AS interName 
					FROM Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.ID=@id;
		WHEN 5 THEN #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #用例ID
			SET isEnable=(SELECT d.IsEnable FROM Case_Detail d WHERE d.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN #已启用
				SET @flag=0;
			ELSE 
				SET @flag=1;
			END IF;
			UPDATE Case_Detail d SET d.IsEnable=@flag WHERE d.ID=@id;
			SELECT '1';
	END CASE;
END;
