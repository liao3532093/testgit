CREATE PROCEDURE pro_implement_info(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#执行详情
	DECLARE caseId INT DEFAULT 0;
	DECLARE result INT DEFAULT 0;
	DECLARE oldTime VARCHAR(255) DEFAULT '';
	DECLARE newTime VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN  #分页查询执行详情
			SET @platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET @interId=pro_split_string(`strs`,'|',2);  #接口ID
			SET @caseName=pro_split_string(`strs`,'|',3);  #用例名称
			SET @state=pro_split_string(`strs`,'|',4);  #状态
			SET oldTime=pro_split_string(`strs`,'|',5);  #前日期
			SET newTime=pro_split_string(`strs`,'|',6);  #后日期
			SET page=pro_split_string(`strs`,'|',7);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',8);  #多少条
			IF @platId>0 && @interId<=0 && @state<0 THEN
				SELECT e.ID,e.CaseID,p.Title AS pName,i.Title AS iName,d.Title AS dName,d.detail,e.Result,e.AddTime FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND p.ID=@platId AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC LIMIT page,pageSize;
			ELSEIF @platId<=0 && @interId>0 && @state<0 THEN
				SELECT e.ID,e.CaseID,p.Title AS pName,i.Title AS iName,d.Title AS dName,d.detail,e.Result,e.AddTime FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND i.ID=@interId AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC LIMIT page,pageSize;
			ELSEIF @platId<=0 && @interId<=0 && @state>=0 THEN
				SELECT e.ID,e.CaseID,p.Title AS pName,i.Title AS iName,d.Title AS dName,d.detail,e.Result,e.AddTime FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND e.Result=@state AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC LIMIT page,pageSize;
			ELSEIF @platId>0 && @interId>0 && @state>=0 THEN
				SELECT e.ID,e.CaseID,p.Title AS pName,i.Title AS iName,d.Title AS dName,d.detail,e.Result,e.AddTime FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND p.ID=@platId AND i.ID=@interId AND e.Result=@state AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC LIMIT page,pageSize;
			ELSE
				SELECT e.ID,e.CaseID,p.Title AS pName,i.Title AS iName,d.Title AS dName,d.detail,e.Result,e.AddTime FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN #分页查询执行详情个数
			SET @platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET @interId=pro_split_string(`strs`,'|',2);  #接口ID
			SET @caseName=pro_split_string(`strs`,'|',3);  #用例名称
			SET @state=pro_split_string(`strs`,'|',4);  #状态
			SET oldTime=pro_split_string(`strs`,'|',5);  #前日期
			SET newTime=pro_split_string(`strs`,'|',6);  #后日期
			IF @platId>0 && @interId<=0 && @state<=0 THEN
				SELECT COUNT(*) FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND p.ID=@platId AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC;
			ELSEIF @platId<=0 && @interId>0 && @state<=0 THEN
				SELECT COUNT(*) FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND i.ID=@interId AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC;
			ELSEIF @platId<=0 && @interId<=0 && @state>0 THEN
				SELECT COUNT(*) FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND e.Result=@state AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC;
			ELSEIF @platId>0 && @interId>0 && @state>0 THEN
				SELECT COUNT(*) FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND p.ID=@platId AND i.ID=@interId AND e.Result=@state AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC;
			ELSE
				SELECT COUNT(*) FROM Execute_Info e JOIN Case_Detail d JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE e.CaseID=d.ID AND d.PlatID=p.ID AND d.InterfaceID=i.ID AND d.Title LIKE CONCAT('%',@caseName,'%') AND e.AddTime BETWEEN oldTime AND newTime ORDER BY e.ID DESC;
			END IF;
		WHEN 3 THEN #加载用例参数
			SET @implId=pro_split_string(`strs`,'|',1);  #所属执行ID
			SELECT m.RequestURL,m.RequestParam,m.ReturnInfo,t.Title AS tName FROM Execute_FinalResult f JOIN Execute_ModelInfo m JOIN Case_ExpectResult e JOIN Dict_ExpectType t
			WHERE f.ExecModelID=m.ID AND f.ExpectID=e.ID AND e.ExpectTypeID=t.ID  AND f.ExecID=@implId;
		WHEN 4 THEN #加载预设参数
			SET @implId=pro_split_string(`strs`,'|',1);  #所属执行ID
			SELECT t.Title AS tName,e.Detail AS tResult,f.Detail,f.Result FROM Execute_FinalResult f JOIN Dict_ExpectType t JOIN Case_ExpectResult e 
			WHERE f.ExpectID=e.ID AND e.ExpectTypeID=t.ID AND f.ExecID=@implId;
		WHEN 5 THEN #取得用例标题
			SET @caseId=pro_split_string(`strs`,'|',1);  #执行的用例ID
			SELECT d.Title FROM Case_Detail d WHERE d.ID=@caseId;
	END CASE;
END;
