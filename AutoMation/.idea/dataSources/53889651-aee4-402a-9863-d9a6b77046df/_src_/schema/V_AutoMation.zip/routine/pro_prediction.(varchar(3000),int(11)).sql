CREATE PROCEDURE pro_prediction(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#预测类型
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #添加修改预测类型
			SET title=pro_split_string(`strs`,'|',1);  #预测类型名称
			SET userId=pro_split_string(`strs`,'|',2);  #用户ID
			SET @id=pro_split_string(`strs`,'|',3);  #预测类型ID
			IF @id>0 THEN  #修改
				UPDATE Dict_ExpectType e SET e.Title=title WHERE e.ID=@id;
			ELSE  #添加
				INSERT INTO Dict_ExpectType VALUES(NULL,title,1,userId,NOW());
			END IF;
			SELECT '1';
		WHEN 2 THEN  #分页查询预测类型
			SET page=pro_split_string(`strs`,'|',1);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',2);  #多少条
			SELECT * FROM Dict_ExpectType e ORDER BY e.ID LIMIT page,pageSize;
		WHEN 3 THEN #分页查询预测类型个数
			SELECT COUNT(*) FROM Dict_ExpectType e ORDER BY e.ID;
		WHEN 4 THEN  #按ID查询
			SET @id=pro_split_string(`strs`,'|',1);  #预测类型ID
			SELECT * FROM Dict_ExpectType e WHERE e.ID=@id;
		WHEN 5 THEN  #启用或禁用
			SET @id=pro_split_string(`strs`,'|',1);  #预测类型ID
			SET isEnable=(SELECT e.IsEnalble FROM Dict_ExpectType e WHERE e.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN #已启用
				SET @flag=0;
			ELSE 
				SET @flag=1;
			END IF;
			UPDATE Dict_ExpectType e SET e.IsEnalble=@flag WHERE e.ID=@id;
			SELECT '1';
		WHEN 6 THEN  #查询预测类型的ID和名称
			SET isEnable=pro_split_string(`strs`,'|',1);  #是否启用
			IF isEnable>0 THEN 
				SELECT e.ID,e.Title FROM Dict_ExpectType e WHERE e.IsEnalble=isEnable;
			ELSE	
				SELECT e.ID,e.Title FROM Dict_ExpectType e;
			END IF;
	END CASE;
END;
