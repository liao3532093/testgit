CREATE PROCEDURE cp_Channel_Update_current_module(IN `_piling_exa_id` INT, IN `_piling_model_id` INT,
                                                  IN `_Isexcute`      INT)
  BEGIN
    
	#设置当前模块模块状态为 执行中
	UPDATE piling_exa_model t1 SET isExecute = `_Isexcute` WHERE t1.state = 1  AND
	 t1.`piling_exa_id` = `piling_exa_id` and t1.piling_model_id =  `_piling_model_id`;
	
    END;
