CREATE PROCEDURE pro_piling_expected_result(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#渠道预期结果
	DECLARE details VARCHAR(255) DEFAULT '';  #说明
	DECLARE num INT DEFAULT 0;  #顺序
	DECLARE state INT DEFAULT 0;  #状态
	DECLARE userId INT DEFAULT 0;  #用户ID
	DECLARE expId INT DEFAULT 0;  #预期类型ID
	DECLARE modelId INT DEFAULT 0;  #渠道模块ID
	DECLARE sqlId INT DEFAULT 0;  #校验模块ID
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;
	DECLARE expVal VARCHAR(255) DEFAULT '';  #预期值
	
	CASE `index`
		WHEN 1 THEN #保存渠道预期结果
			SET details=pro_split_string(`strs`,'|',1);  #说明
			SET num=pro_split_string(`strs`,'|',2);  #顺序
			SET state=pro_split_string(`strs`,'|',3);  #状态
			SET expId=pro_split_string(`strs`,'|',4);  #预期类型ID
			SET modelId=pro_split_string(`strs`,'|',5);  #渠道模块ID
			SET sqlId=pro_split_string(`strs`,'|',6);  #校验模块ID
			SET userId=pro_split_string(`strs`,'|',7);  #用户ID
			SET @id=pro_split_string(`strs`,'|',8);  #ID
			SET @count=(SELECT COUNT(*) FROM piling_expected_result r WHERE r.exp_num=num AND r.pil_model_id=modelId);
			SET expVal=(SELECT s.ExpectValue FROM Dict_ExecuteSql s WHERE s.ID=sqlId);
			IF @id>0 THEN  #修改
				SET @old=(SELECT r.exp_num FROM piling_expected_result r WHERE r.id=@id);
				IF @count>0 && num!=@old THEN
					SELECT '-1';
				ELSE
					UPDATE piling_expected_result r SET r.exp_details=details,r.exp_num=num,r.state=state,r.exp_id=expId
					,r.sql_id=sqlId,r.userId=userId,r.ExpectValue=expVal WHERE r.id=@id;
					SELECT '1';
				END IF;
			ELSE  #添加 
				IF @count>0 THEN 
					SELECT '-1';
				ELSE
					INSERT INTO piling_expected_result VALUES(NULL,details,num,state,modelId,expId,sqlId,NOW(),userId,expVal);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询渠道预期结果
			SET modelId=pro_split_string(`strs`,'|',1);  #渠道模块ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT *,t.Title AS expName,s.ExecuteSql AS sqlName,s.ExpectValue AS eValue FROM piling_expected_result r JOIN Dict_ExpectType t JOIN Dict_ExecuteSql s 
				WHERE r.exp_id=t.ID AND r.sql_id=s.ID AND r.pil_model_id=modelId ORDER BY r.exp_num LIMIT page,pageSize;
		WHEN 3 THEN #分页查询渠道预期结果个数
			SET modelId=pro_split_string(`strs`,'|',1);  #渠道模块ID
			SELECT COUNT(*) FROM piling_expected_result r JOIN Dict_ExpectType t JOIN Dict_ExecuteSql s 
				WHERE r.exp_id=t.ID AND r.sql_id=s.ID AND r.pil_model_id=modelId ORDER BY r.exp_num;
		WHEN 4 THEN #禁用和启用
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SET state=(SELECT r.state FROM piling_expected_result r WHERE r.id=@id);
			SET @len=0;
			IF state=0 THEN 
				SET @len=1;
			ELSE
				SET @len=0;
			END IF;
			UPDATE piling_expected_result r SET r.state=@len WHERE r.id=@id;
			SELECT '1';
		WHEN 5 THEN #按ID查询渠道预期结果
			SET modelId=pro_split_string(`strs`,'|',1);  #渠道模块ID
			SET @id=pro_split_string(`strs`,'|',2);  #ID
			SELECT * FROM piling_expected_result r WHERE r.pil_model_id=modelId AND r.id=@id;
	END CASE;
END;
