CREATE PROCEDURE cp_Channel_Model_GetRecordList_Two(IN id INT, IN ModelType INT)
  BEGIN
    SELECT 
		t3.`id`,
		t1.`piling_model_id`,
		t1.`piling_exa_id`,
		t2.`piling_example_title`,
		t3.`request_url`,
		t3.`request_type`,
		t3.`response_item`,
		t2.`state`
	FROM piling_exa_model t1 
	JOIN piling_example t2  on t1.piling_exa_id = t2.id
	JOIN piling_model t3    ON t1.piling_model_id = t3.id
	WHERE   t2.`state` = 1
	AND 	t3.`modelType` = `ModelType` 
	AND 	t1.state = 1 
	and 	t2.id = `id` 
	AND 	t1.`exe_order` = 1
	ORDER BY t1.`exe_order` ASC;
    END;
