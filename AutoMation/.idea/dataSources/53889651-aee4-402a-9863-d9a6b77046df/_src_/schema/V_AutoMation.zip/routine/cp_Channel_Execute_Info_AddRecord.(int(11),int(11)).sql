CREATE PROCEDURE cp_Channel_Execute_Info_AddRecord(IN pil_exa_id INT, IN result INT)
  BEGIN
	INSERT INTO piling_execute_info(
		`pil_exa_id`,
		`result`,
		`execute_time`,
		`isExecute` )
	VALUES(
		`pil_exa_id`,
		`result`,
		CURTIME(),
		1 );
		
		
	
	#UPDATE piling_exa_model t1 SET isExecute = 0 WHERE t1.state = 1 and t1.`piling_exa_id` = `piling_exa_id`;
	SELECT	LAST_INSERT_ID();
END;
