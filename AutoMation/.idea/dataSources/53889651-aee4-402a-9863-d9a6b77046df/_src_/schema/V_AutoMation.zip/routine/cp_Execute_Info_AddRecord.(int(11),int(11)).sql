CREATE PROCEDURE cp_Execute_Info_AddRecord(IN CaseID INT, IN Result INT)
  BEGIN

	INSERT INTO Execute_Info(
		`CaseID`,
		`Result`,
		`AddTime` )
	VALUES(
		`CaseID`,
		`Result`,
		CURTIME() );
	SELECT	@@IDENTITY,`CaseID`,`Result`;
END;
