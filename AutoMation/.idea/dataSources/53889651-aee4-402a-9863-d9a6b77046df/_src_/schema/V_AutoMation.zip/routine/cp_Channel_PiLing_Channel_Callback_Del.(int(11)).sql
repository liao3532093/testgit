CREATE PROCEDURE cp_Channel_PiLing_Channel_Callback_Del(IN `_ID` INT)
  BEGIN
		delete from PiLing_Channel_Callback where ID = `_ID`;
    END;
