CREATE PROCEDURE pro_case_modelparam(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用例模块参数
	DECLARE modelID INT DEFAULT 0;  #用例模块ID
	DECLARE paramID INT DEFAULT 0;  #参数ID
	DECLARE val VARCHAR(255) DEFAULT '';  #参数值或方法
	DECLARE userId INT DEFAULT 0;  #新增人用户ID
	DECLARE valueType INT DEFAULT 0;  #参数类型（1=值类型；2=方法类型）
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #保存用例模块参数
			SET modelID=pro_split_string(`strs`,'|',1);  #用例模块ID
			SET paramID=pro_split_string(`strs`,'|',2);  #参数ID
			SET val=pro_split_string(`strs`,'|',3);  #参数值或方法
			SET userId=pro_split_string(`strs`,'|',4);  #新增人用户ID
			SET valueType=pro_split_string(`strs`,'|',5);  #参数类型（1=值类型；2=方法类型）
			INSERT INTO Case_ModelParam VALUES(NULL,modelID,paramID,val,userId,NOW(),valueType);
			SELECT '1';
		WHEN 2 THEN #保存时删除
			SET modelID=pro_split_string(`strs`,'|',1);  #用例模块ID
			DELETE FROM Case_ModelParam WHERE CaseModelID=modelID;
			SELECT '1';
		WHEN 3 THEN #按用例模块ID查询
			SET modelID=pro_split_string(`strs`,'|',1);  #用例模块ID
			SELECT * FROM Case_ModelParam m WHERE m.CaseModelID=modelID;
	END CASE;
END;
