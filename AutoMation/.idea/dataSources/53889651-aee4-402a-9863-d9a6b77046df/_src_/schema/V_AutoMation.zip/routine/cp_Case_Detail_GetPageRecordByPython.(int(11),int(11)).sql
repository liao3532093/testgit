CREATE PROCEDURE cp_Case_Detail_GetPageRecordByPython(IN Page INT, IN PageSize INT)
  BEGIN
	DECLARE iBeginID       	INT;
	DECLARE iEndID         	INT;
	DECLARE RowCount	INT;
	
	SET iBeginID = (`Page`-1) * `PageSize`;
	SET iEndID = `PageSize`;
	SET `RowCount` = 0;
	SELECT COUNT(`ID`) INTO `RowCount`  FROM Case_Detail;
	IF (`RowCount` > 0)
	THEN
		SET @iID = 0;
		SELECT @iID:=IFNULL(@iID,0)+1 AS R_Number,
			t1.`ID`
			,t1.`PlatID`
			,t1.`InterfaceID`
			,t2.`Title` as `PlatFormName`
			,t3.`Title` as `InterfaceName`
			,t1.`Title` as `CaseName`
			,t1.`Detail`
			,t1.`IsEnable`			
		FROM Case_Detail t1
		join Dict_PlatForm t2 	on t2.`ID` = t1.`PlatID`
		JOIN Dict_Interface t3 	on t3.`ID` = t1.`InterfaceID`
		WHERE t1.`IsEnable` = 1
		ORDER BY R_Number DESC
		LIMIT iBeginID,iEndID;
	END IF;
END;
