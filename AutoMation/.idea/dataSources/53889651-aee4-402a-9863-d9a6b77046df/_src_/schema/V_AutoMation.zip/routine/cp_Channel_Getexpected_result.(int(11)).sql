CREATE PROCEDURE cp_Channel_Getexpected_result(IN pil_model_id INT)
  BEGIN	
	select 
		 t1.`id`
		,t1.`pil_model_id`
		,t1.`exp_details`
		,t1.`sql_id`
		,t2.`PlatID`
		,t2.`ExpectTypeID`
		,t2.`ExecuteSql`
		,t1.`ExpectValue`
		
	from piling_expected_result t1  
	JOIN Dict_ExecuteSql t2 On t2.`ID` = t1.`sql_id`
	where t1.`pil_model_id` = `pil_model_id` AND t1.`state` = 1
	order by t1.`exp_num` asc;
END;
