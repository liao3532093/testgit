CREATE PROCEDURE pro_log_type(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#日志信息
	DECLARE lkey VARCHAR(255) DEFAULT '';
	DECLARE ltitle VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN  #保存日志类型信息
			SET lkey=pro_split_string(`strs`,'|',1);  #日志类型关键字
			SET ltitle=pro_split_string(`strs`,'|',2);  #日志类型
			SET @id=pro_split_string(`strs`,'|',3);  #日志类型ID
			SET @count=(SELECT COUNT(*) FROM Log_Type l WHERE l.LogKey=lkey);
			IF @id>0 THEN #修改
				SET @lname=(SELECT l.LogKey FROM Log_Type l WHERE l.ID=@id);
				IF @count<=0 || lkey=@lname THEN  #可以修改	
					UPDATE Log_Type l SET l.LogKey=lkey,l.Title=ltitle WHERE l.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
			ELSE  #添加 
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO Log_Type VALUES(NULL,lkey,ltitle,true);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询日志类型
			SET page=pro_split_string(`strs`,'|',1);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',2);  #多少条
			SELECT * FROM Log_Type l ORDER BY l.ID LIMIT page,pageSize;
		WHEN 3 THEN #分页查询日志类型个数 
			SELECT COUNT(*) FROM Log_Type l ORDER BY l.ID;
		WHEN 4 THEN #按ID查询日志类型
			SET @id=pro_split_string(`strs`,'|',1);  #日志类型ID
			SELECT * FROM Log_Type l WHERE l.ID=@id;
		WHEN 5 THEN #删除日志类型
			SET @id=pro_split_string(`strs`,'|',1);  #日志类型ID
			DELETE FROM Log_Type WHERE ID=@id;
			SELECT '1';
	END CASE;
END;
