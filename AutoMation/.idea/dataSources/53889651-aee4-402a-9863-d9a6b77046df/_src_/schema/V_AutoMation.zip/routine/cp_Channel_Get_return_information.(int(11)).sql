CREATE PROCEDURE cp_Channel_Get_return_information(IN `_isExecute` INT)
  BEGIN
		select 
			t1.piling_model_id,
			t1.piling_exa_id,
			t1.exa_value,
			t1.isExecute,
			t1.exe_order,
			t2.modelType,
			t1.`id`,
			t2.`request_url`
		from piling_exa_model t1 
		join piling_model t2 ON t2.`id` = t1.`piling_model_id`
		where t1.isExecute = `_isExecute` and isExecute = 1 
		LIMIT 1;
    END;
