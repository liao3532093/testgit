CREATE PROCEDURE pro_admin_powerlist(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用户相对的权限
	DECLARE uId INT DEFAULT 0;
	DECLARE powerTxt LONGTEXT DEFAULT '';

	CASE `index`
		WHEN 1 THEN  #查询用户权限
			SET uId=pro_split_string(`strs`,'|',1);  #用户ID
			SELECT * FROM Admin_PowerList p WHERE p.UserID=uId;
		WHEN 2 THEN #保存用户权限
			SET uId=pro_split_string(`strs`,'|',1);  #用户ID
			SET powerTxt=pro_split_string(`strs`,'|',2);  #权限内容
			SET @id=(SELECT p.ID FROM Admin_PowerList p WHERE p.UserID=uId);
			IF @id>0 THEN
				UPDATE Admin_PowerList p SET p.PowerName=powerTxt WHERE p.ID=@id;
				SELECT '1';
			ELSE
				INSERT INTO Admin_PowerList VALUES(NULL,powerTxt,uId);
				SELECT '1';
			END IF;
		WHEN 3 THEN 
			SET @showName=pro_split_string(`strs`,'|',1);  #用户ID
			SET @manName=pro_split_string(`strs`,'|',2);  #用户ID
			SET @count=(SELECT COUNT(*) FROM Admin_PowerItem m WHERE m.Keywords=@showName);
	END CASE;
END;
