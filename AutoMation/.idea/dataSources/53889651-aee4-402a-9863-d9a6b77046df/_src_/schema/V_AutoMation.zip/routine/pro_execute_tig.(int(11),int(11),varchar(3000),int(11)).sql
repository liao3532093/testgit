CREATE PROCEDURE pro_execute_tig(IN caseId INT, IN result INT, IN time VARCHAR(3000), IN `index` INT)
  BEGIN
	#统计数据触发器
	DECLARE caseId INT DEFAULT 0;
	DECLARE res INT DEFAULT 0;
	DECLARE tims VARCHAR(3000) DEFAULT '';
	DECLARE success INT DEFAULT 0;
	DECLARE fail INT DEFAULT 0;
	DECLARE error INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN  #添加
			SET caseId=`caseId`;
			SET res=`result`;
			SET @date=pro_split_string(NOW(),' ',1);
			SET @pid=(SELECT c.PlatID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=c.ID LIMIT 1); #平台ID
			SET @iid=(SELECT c.InterfaceID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=c.ID LIMIT 1); #接口ID
			SET @count=(SELECT COUNT(*) FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
			IF @count>0 THEN #修改
				SET @id=(SELECT e.ID FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
				SET success=(SELECT e.SuccessNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				SET error=(SELECT e.FailNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				SET fail=(SELECT e.ErrorNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				IF res=1 THEN
					SET error=error+1;
					UPDATE Stat_ExecuteDay e SET e.FailNum=error WHERE e.ID=@id;
				ELSEIF res=2 THEN
					SET success=success+1;
					UPDATE Stat_ExecuteDay e SET e.SuccessNum=success WHERE e.ID=@id;
				ELSEIF res=3 THEN
					SET fail=fail+1;
					UPDATE Stat_ExecuteDay e SET e.ErrorNum=fail WHERE e.ID=@id;
				END IF;
			ELSE  #添加
				IF res=1 THEN #失败
					SET error=error+1;
				ELSEIF res=2 THEN #成功
					SET success=success+1;
				ELSEIF res=3 THEN #脚本异常
					SET fail=fail+1;
				END IF; 
				INSERT INTO Stat_ExecuteDay VALUES(NULL,success,error,@date,NOW(),@pid,@iid,fail);
			END IF;
		WHEN 2 THEN #删除
			SET caseId=`caseId`;
			SET res=`result`;
			SET @date=pro_split_string(NOW(),' ',1);
			SET @pid=(SELECT c.PlatID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=c.ID LIMIT 1); #平台ID
			SET @iid=(SELECT c.InterfaceID FROM Execute_Info e JOIN Case_Detail c WHERE e.CaseID=c.ID LIMIT 1); #接口ID
			SET @count=(SELECT COUNT(*) FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
			IF @count>0 THEN #删除
				SET @id=(SELECT e.ID FROM Stat_ExecuteDay e WHERE e.PlatID=@pid AND e.InterfaceID=@iid AND e.ExecTime BETWEEN CONCAT(@date,' ','00:00:00') AND CONCAT(@date,' ','23:59:59'));
				SET success=(SELECT e.SuccessNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				SET fail=(SELECT e.FailNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				SET error=(SELECT e.ErrorNum FROM Stat_ExecuteDay e WHERE e.ID=@id);
				IF res=1 THEN #失败
					SET error=error-1;
				ELSEIF res=2 THEN #成功
					SET success=success-1;
				ELSEIF res=3 THEN #脚本异常
					SET fail=fail-1;
				END IF;
				UPDATE Stat_ExecuteDay e SET e.SuccessNum=success,e.FailNum=error,e.ExecTime=@date,e.ErrorNum=fail WHERE e.ID=@id;
				IF success=0 && fail=0 && error=0 THEN
					DELETE FROM Stat_ExecuteDay WHERE ID=@id;
				END IF;
			END IF;
		WHEN 2 THEN #修改
			SET caseId=`caseId`;
			SET res=`result`;
	END CASE;
END;
