CREATE PROCEDURE cp_Channel_IsCallback(IN `_modelType` INT, IN `_exe_order` INT, IN `_piling_exa_id` INT)
  BEGIN
    select
	t1.id,
	t1.`piling_model_id`,
	t1.`piling_exa_id`,
	t1.`exa_value`,
	t1.`exe_order` ,
	t1.`isExecute`,
	t2.`modelType`,
	t2.`request_url`,
	t2.`request_type`
from `piling_exa_model` t1
join `piling_model` t2  JOIN piling_example t3 
ON t2.`id` = t1.`piling_model_id` AND t2.`modelType` = `_modelType`
WHERE t1.exe_order = `_exe_order` and t1.piling_exa_id = `_piling_exa_id` and t1.`piling_exa_id` =  t3.`id` 
and t1.`state` = 1 and t2.`state` = 1;
    END;
