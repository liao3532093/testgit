CREATE PROCEDURE cp_Execute_Info_UpdateRecord(IN `_ID` INT, IN `_result` INT)
  BEGIN
		update Execute_Info set   Result = `_result`
	
		WHERE ID = `_ID`;
    END;
