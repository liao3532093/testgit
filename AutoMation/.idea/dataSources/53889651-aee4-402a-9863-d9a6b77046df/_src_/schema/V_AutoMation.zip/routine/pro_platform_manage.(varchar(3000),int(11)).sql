CREATE PROCEDURE pro_platform_manage(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#平台管理
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	
	CASE `index`
		WHEN 1 THEN  #添加平台名称
			SET title=pro_split_string(`strs`,'|',1);
			SET userId=pro_split_string(`strs`,'|',2);
			SET @count=(SELECT COUNT(*) FROM Dict_PlatForm p WHERE p.Title=title);
			IF @count>0 THEN
				SELECT '-1';
			ELSE
				INSERT INTO Dict_PlatForm VALUES(NULL,title,true,userId,NOW());
				SELECT '1';
			END IF;
		WHEN 2 THEN #查询所有平台名称信息
			SET page=pro_split_string(`strs`,'|',1);
			SET pageSize=pro_split_string(`strs`,'|',2);
			SELECT * FROM Dict_PlatForm p ORDER BY p.ID LIMIT page,pageSize;
		WHEN 3 THEN #修改平台名称信息
			SET @id=pro_split_string(`strs`,'|',1);
			SET title=pro_split_string(`strs`,'|',2);
			UPDATE Dict_PlatForm p SET p.Title=title WHERE p.ID=@id;
			SELECT '1';
		WHEN 4 THEN  #禁用平台名称信息
			SET @id=pro_split_string(`strs`,'|',1);
			SET @enab=(SELECT p.IsEnable FROM Dict_PlatForm p WHERE p.ID=@id);
			IF @enab>0 THEN
				UPDATE Dict_PlatForm p SET p.IsEnable=0 WHERE p.ID=@id;
			ELSE
				UPDATE Dict_PlatForm p SET p.IsEnable=1 WHERE p.ID=@id;
			END IF;
			SELECT '1';
		WHEN 5 THEN  #查询平台名称过滤禁用
			SELECT * FROM Dict_PlatForm p WHERE p.IsEnable='1';
		WHEN 6 THEN  #查询所有平台信息个数
			SELECT COUNT(*) FROM Dict_PlatForm p ORDER BY p.ID;
		WHEN 7 THEN #按ID查询平台名称
			SET @id=pro_split_string(`strs`,'|',1);
			SELECT p.Title FROM Dict_PlatForm p WHERE p.ID=@id;
	END CASE;
END;
