CREATE PROCEDURE pro_platform_request(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#请求模块
	DECLARE platId INT DEFAULT 0;
	DECLARE interfaceId INT DEFAULT 0;
	DECLARE title VARCHAR(255) DEFAULT '';
	DECLARE requestUrl VARCHAR(255) DEFAULT '';
	DECLARE requestType INT DEFAULT 0;
	DECLARE paramType INT DEFAULT 0;
	DECLARE userId INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #添加请求用例信息
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET interfaceId=pro_split_string(`strs`,'|',2);  #接口ID
			SET title=pro_split_string(`strs`,'|',3);  #模块名称
			SET requestUrl=pro_split_string(`strs`,'|',4);  #模块地址
			SET requestType=pro_split_string(`strs`,'|',5);  #模块地址
			SET paramType=pro_split_string(`strs`,'|',6);  #参数格式
			SET isEnable=pro_split_string(`strs`,'|',7);  #状态
			SET userId=pro_split_string(`strs`,'|',8);  #用户ID
			SET @id=pro_split_string(`strs`,'|',9);  #用例ID
			IF @id>0 THEN #修改
				UPDATE Dict_RequestModel r SET r.PlatID=platId,r.InterfaceID=interfaceId,r.Title=title,r.RequestURL=requestUrl,
							r.RequestType=requestType,r.ParamType=paramType,r.IsEnable=isEnable,r.AddUserID=userId WHERE r.ID=@id;
			ELSE
				INSERT INTO Dict_RequestModel VALUES(NULL,platId,interfaceId,title,requestUrl,requestType,paramType,isEnable,userId,NOW());
			END IF;
			SELECT '1';
		WHEN 2 THEN  #分页查询所有用例信息
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET interfaceId=pro_split_string(`strs`,'|',2);  #接口ID
			SET title=pro_split_string(`strs`,'|',3);  #模块名称
			SET page=pro_split_string(`strs`,'|',4);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',5);  #多少条
			IF platId>0 && interfaceId<=0 THEN
				SELECT r.*,f.Title AS platName,i.Title AS interName FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.PlatID=platId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID LIMIT page,pageSize;
			ELSEIF interfaceId>0&&platId<=0 THEN
				SELECT r.*,f.Title AS platName,i.Title AS interName FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.InterfaceID=interfaceId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID LIMIT page,pageSize;
			ELSEIF platId>0&&interfaceId>0 THEN
				SELECT r.*,f.Title AS platName,i.Title AS interName FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.InterfaceID=interfaceId AND r.PlatID=platId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID LIMIT page,pageSize;
			ELSE
				SELECT r.*,f.Title AS platName,i.Title AS interName FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID LIMIT page,pageSize;
			END IF;
		WHEN 3 THEN #查询用例信息个数
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET interfaceId=pro_split_string(`strs`,'|',2);  #接口ID
			SET title=pro_split_string(`strs`,'|',3);  #模块名称
			IF platId>0 && interfaceId<=0 THEN
				SELECT COUNT(*) FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.PlatID=platId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID;
			ELSEIF interfaceId>0&&platId<=0 THEN
				SELECT COUNT(*) FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.InterfaceID=interfaceId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID;
			ELSEIF platId>0&&interfaceId>0 THEN
				SELECT COUNT(*) FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.InterfaceID=interfaceId AND r.PlatID=platId AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID;
			ELSE
				SELECT COUNT(*) FROM Dict_RequestModel r JOIN Dict_Interface i JOIN Dict_PlatForm f 
							WHERE r.PlatID=f.ID AND r.InterfaceID=i.ID AND r.Title LIKE CONCAT('%',title,'%') ORDER BY r.ID;
			END IF;
		WHEN 4 THEN  #按ID查询用例信息
			SET @id=pro_split_string(`strs`,'|',1);  #用例ID
			SELECT * FROM Dict_RequestModel r WHERE r.ID=@id;
		WHEN 5 THEN #查询所有请求模块的名称的ID
			SELECT * FROM Dict_RequestModel;
		WHEN 6 THEN #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #用例ID
			SET isEnable=(SELECT r.IsEnable FROM Dict_RequestModel r WHERE r.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN  #已启用
				SET @flag=0;
			ELSE
				SET @flag=1;
			END IF;
			UPDATE Dict_RequestModel r SET r.IsEnable=@flag WHERE r.ID=@id;
			SELECT '1';
	END CASE;
END;
