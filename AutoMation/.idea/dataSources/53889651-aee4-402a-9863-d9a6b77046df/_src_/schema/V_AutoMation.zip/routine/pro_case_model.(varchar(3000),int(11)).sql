CREATE PROCEDURE pro_case_model(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用例模块
	DECLARE caseId INT DEFAULT 0;
	DECLARE modelId INT DEFAULT 0;
	DECLARE orderNum INT DEFAULT 0;
	DECLARE isEnable INT DEFAULT 0;
	DECLARE userId INT DEFAULT 0;
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询用例模块
			SET caseId=pro_split_string(`strs`,'|',1);  #用例详情ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT m.ID,m.CaseID,m.ModelID,m.OrderNum,m.IsEnable,m.AddUserID,m.Addtime,r.Title AS modelName,r.RequestURL AS modelUrl 
				FROM Case_Model m JOIN Dict_RequestModel r JOIN Case_Detail d WHERE m.ModelID=r.ID AND m.CaseID=d.ID AND d.ID=caseId 
				ORDER BY m.OrderNum LIMIT page,pageSize;
		WHEN 2 THEN  #分页查询用例模块个数
			SET caseId=pro_split_string(`strs`,'|',1);  #用例详情ID
			SELECT  COUNT(*) FROM Case_Model m JOIN Dict_RequestModel r JOIN Case_Detail d WHERE m.ModelID=r.ID AND m.CaseID=d.ID AND d.ID=caseId 
				ORDER BY m.OrderNum;
		WHEN 3 THEN #保存用例模块
			SET caseId=pro_split_string(`strs`,'|',1);  #用例详情ID
			SET modelId=pro_split_string(`strs`,'|',2);  #模块ID
			SET orderNum=pro_split_string(`strs`,'|',3);  #执行顺序
			SET isEnable=pro_split_string(`strs`,'|',4);  #是否可用
			SET userId=pro_split_string(`strs`,'|',5);  #新增人ID
			SET @id=pro_split_string(`strs`,'|',6);  #用例模块ID
			IF @id>0 THEN #修改
				SET @num=(SELECT m.OrderNum FROM Case_Model m WHERE m.ID=@id AND m.CaseID=caseId);
				SET @count=(SELECT COUNT(*) FROM Case_Model m WHERE m.OrderNum=orderNum AND m.CaseID=caseId);
				IF @count<=0 || orderNum=@num THEN
					UPDATE Case_Model m SET m.CaseID=caseId,m.ModelID=modelId,m.OrderNum=orderNum,m.IsEnable=isEnable,m.AddUserID=userId WHERE m.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
			ELSE #添加 
				SET @count=(SELECT COUNT(*) FROM Case_Model m WHERE m.OrderNum=orderNum AND m.CaseID=caseId);
				IF @count>0 THEN 
					SELECT '-1';
				ELSE
					INSERT INTO Case_Model VALUES(NULL,caseId,modelId,orderNum,isEnable,userId,NOW());
					SELECT '1';
				END IF;
			END IF;
		WHEN 4 THEN #通过ID查询模块信息
			SET @id=pro_split_string(`strs`,'|',1);  #用例模块ID
			SET @cid=(SELECT m.CaseID FROM Case_Model m WHERE m.ID=@id);
			SELECT m.ID,m.CaseID,m.ModelID,d.Title AS caseName,r.Title AS modelName 
				FROM Case_Model m JOIN Case_Detail d JOIN Dict_RequestModel r 
				WHERE m.CaseID=d.ID AND m.ModelID=r.ID AND m.CaseID=@cid AND m.ID=@id;
		WHEN 5 THEN #查询刚插入的ID
			SELECT m.ID FROM Case_Model m ORDER BY m.ID DESC LIMIT 0,1;
	END CASE;
END;
