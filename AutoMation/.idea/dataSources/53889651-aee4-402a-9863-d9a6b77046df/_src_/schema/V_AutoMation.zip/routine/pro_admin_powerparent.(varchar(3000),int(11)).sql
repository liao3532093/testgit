CREATE PROCEDURE pro_admin_powerparent(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#权限小类别
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	
	CASE `index`
		WHEN 1 THEN #保存权限小类别
			SET @title=pro_split_string(`strs`,'|',1);  #小类别权限名称
			SET @isLock=pro_split_string(`strs`,'|',2);  #是否锁定
			SET @orderNo=pro_split_string(`strs`,'|',3);  #排序（从小到大排序）
			SET @pClassId=pro_split_string(`strs`,'|',4);  #大类别权限ID
			SET @id=pro_split_string(`strs`,'|',5);  #小类别权限ID
			SET @flag=false;
			IF @isLock>0 THEN
				SET @flag=true;
			ELSE
				SET @flag=false;
			END IF;
			IF @id>0 THEN #修改
				SET @num=(SELECT p.OrderNo FROM Admin_PowerParent p WHERE p.ID=@id AND p.PowerClassID=@pClassId);
				SET @count=(SELECT COUNT(*) FROM Admin_PowerParent p WHERE p.OrderNo=@orderNo AND p.PowerClassID=@pClassId);
				IF @count<=0 || @orderNo=@num THEN
					UPDATE Admin_PowerParent p SET p.Title=@title,p.PowerClassID=@pClassId,p.IsLock=@flag,p.OrderNo=@orderNo WHERE p.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
			ELSE
				SET @count=(SELECT COUNT(*) FROM Admin_PowerParent p WHERE p.OrderNo=@orderNo AND p.PowerClassID=@pClassId);
				IF @count>0 THEN
					SELECT '-1';
				ELSE
					INSERT INTO Admin_PowerParent VALUES(NULL,@title,@pClassId,@flag,@orderNo);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询权限小类别
			SET @pClassId=pro_split_string(`strs`,'|',1);  #大类别权限ID
			SET page=pro_split_string(`strs`,'|',2);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT * FROM Admin_PowerParent p WHERE p.PowerClassID=@pClassId ORDER BY p.ID LIMIT page,pageSize;
		WHEN 3 THEN #分页查询权限小类别个数
			SET @pClassId=pro_split_string(`strs`,'|',1);  #大类别权限ID
			SELECT COUNT(*) FROM Admin_PowerParent p WHERE p.PowerClassID=@pClassId ORDER BY p.ID;
		WHEN 4 THEN #按ID查询权限小类别
			SET @id=pro_split_string(`strs`,'|',1);  #小类别权限ID
			SELECT * FROM Admin_PowerParent p WHERE p.ID=@id;
		WHEN 5 THEN #查询没有禁用的权限小类别
			SET @pClassId=pro_split_string(`strs`,'|',1);  #大类别权限ID
			SELECT * FROM Admin_PowerParent p WHERE p.IsLock=false AND p.PowerClassID=@pClassId;
	END CASE;
END;
