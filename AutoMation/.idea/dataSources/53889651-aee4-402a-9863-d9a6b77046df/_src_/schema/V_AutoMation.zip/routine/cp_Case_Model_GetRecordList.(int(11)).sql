CREATE PROCEDURE cp_Case_Model_GetRecordList(IN CaseID INT)
  BEGIN
	SELECT
		t1.`ID`
		,t1.`CaseID`
		,t1.`ModelID`
		,t2.`Title` AS `ModelTitle`
		,t2.`RequestURL`
		,t2.`RequestType`
		,t2.`ParamType`
	FROM Case_Model t1
	JOIN Dict_RequestModel t2 ON t2.`ID` = t1.`ModelID`
	WHERE t1.`CaseID` = `CaseID` AND t1.`IsEnable` = 1;
	
END;
