CREATE PROCEDURE pro_case_statistics(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用例平台统计
	DECLARE platID INT DEFAULT 0;
	DECLARE interId INT DEFAULT 0;
	DECLARE oldTime VARCHAR(255) DEFAULT '';
	DECLARE newTime VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;
	DECLARE lens INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN #分页查询用例平台统计
			SET platID=pro_split_string(`strs`,'|',1);  #平台ID
			SET oldTime=pro_split_string(`strs`,'|',2);  #开始日期
			SET newTime=pro_split_string(`strs`,'|',3);  #结束日期
			SET page=pro_split_string(`strs`,'|',4);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',5);  #多少条
			IF platID>0 THEN
				SELECT p.Title AS platName ,SUM(s.SuccessNum) AS SuccessNum,SUM(s.FailNum) AS FailNum,
				SUM(s.ErrorNum) AS ErrorNum,s.ExecTime,s.PlatID AS platID,s.ID 
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.PlatID=platID AND s.ExecTime BETWEEN oldTime AND newTime 
				GROUP BY s.ExecTime ORDER BY s.ExecTime DESC LIMIT page,pageSize;
			ELSE
				SELECT p.Title AS platName ,SUM(s.SuccessNum) AS SuccessNum,SUM(s.FailNum) AS FailNum,
				SUM(s.ErrorNum) AS ErrorNum,s.ExecTime,s.PlatID AS platID,s.ID 
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.ExecTime BETWEEN oldTime AND newTime 
				GROUP BY s.ExecTime ORDER BY s.ExecTime DESC LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN #分页查询用例平台统计个数
			SET platID=pro_split_string(`strs`,'|',1);  #平台ID
			SET oldTime=pro_split_string(`strs`,'|',2);  #开始日期
			SET newTime=pro_split_string(`strs`,'|',3);  #结束日期
			IF platID>0 THEN
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.PlatID=platID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			ELSE
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i 
				WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			END IF;
		WHEN 3 THEN #查询平台数据
			SELECT s.PlatID FROM Stat_ExecuteDay s;
		WHEN 4 THEN #分页查询用例接口统计
			SET platID=pro_split_string(`strs`,'|',1);  #平台ID
			SET interId=pro_split_string(`strs`,'|',2);  #接口ID
			SET oldTime=pro_split_string(`strs`,'|',3);  #开始日期
			SET newTime=pro_split_string(`strs`,'|',4);  #结束日期
			SET page=pro_split_string(`strs`,'|',5);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',6);  #多少条
			IF platID>0 && interId<=0 THEN
				SELECT p.Title AS platName,i.Title AS interName,s.SuccessNum,s.FailNum,
				s.ExecTime,s.ErrorNum,s.ID
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND p.ID=platID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime LIMIT page,pageSize;
			ELSEIF platID<=0 && interId>0 THEN
				SELECT p.Title AS platName,i.Title AS interName,s.SuccessNum,s.FailNum,
				s.ExecTime,s.ErrorNum,s.ID
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND i.ID=interId AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime LIMIT page,pageSize;
			ELSEIF platID>0 && interId>0 THEN
				SELECT p.Title AS platName,i.Title AS interName,s.SuccessNum,s.FailNum,
				s.ExecTime,s.ErrorNum,s.ID
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND i.ID=interId AND p.ID=platID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime LIMIT page,pageSize;
			ELSE
				SELECT p.Title AS platName,i.Title AS interName,s.SuccessNum,s.FailNum,
				s.ExecTime,s.ErrorNum,s.ID
				FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime LIMIT page,pageSize;
			END IF;
		WHEN 5 THEN  #分页查询用例接口统计个数
			SET platID=pro_split_string(`strs`,'|',1);  #平台ID
			SET interId=pro_split_string(`strs`,'|',2);  #接口ID
			SET oldTime=pro_split_string(`strs`,'|',3);  #开始日期
			SET newTime=pro_split_string(`strs`,'|',4);  #结束日期
			IF platID>0 && interId<=0 THEN
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND p.ID=platID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			ELSEIF platID<=0 && interId>0 THEN
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND i.ID=interId AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			ELSEIF platID>0 && interId>0 THEN
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND i.ID=interId AND p.ID=platID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			ELSE
				SELECT COUNT(*) FROM Stat_ExecuteDay s JOIN Dict_PlatForm p JOIN Dict_Interface i WHERE s.PlatID=p.ID AND s.InterfaceID=i.ID AND s.ExecTime BETWEEN oldTime AND newTime ORDER BY s.ExecTime;
			END IF;
		WHEN 6 THEN # 查询平台和接口数据
			SELECT e.PlatID,e.InterfaceID FROM Stat_ExecuteDay e;
		WHEN 7 THEN #通过ID去查询平台统计
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SELECT * FROM Stat_ExecuteDay s WHERE s.ID=@id;
		WHEN 8 THEN  #取得当天运行用例总数
			SET oldTime=pro_split_string(`strs`,'|',1);  #开始日期
			SET newTime=pro_split_string(`strs`,'|',2);  #结束日期
			SELECT COUNT(e.Result) AS caseCount,s.ID FROM Stat_ExecuteDay s JOIN Execute_Info e 
			WHERE s.ExecTime=DATE_FORMAT(e.AddTime,'%Y-%m-%d') AND s.ExecTime BETWEEN oldTime AND newTime GROUP BY s.ExecTime;
	END CASE;
END;
