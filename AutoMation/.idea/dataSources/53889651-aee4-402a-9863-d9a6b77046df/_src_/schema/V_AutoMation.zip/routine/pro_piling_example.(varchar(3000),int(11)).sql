CREATE PROCEDURE pro_piling_example(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#渠道用例
	DECLARE platId INT DEFAULT 0;  #平台ID
	DECLARE pilName VARCHAR(255) DEFAULT '';  #用例名称
	DECLARE state INT DEFAULT 0;  #状态
	DECLARE userId INT DEFAULT 0;  #用户ID
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN #保存渠道用例
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET pilName=pro_split_string(`strs`,'|',2);  #用例名称
			SET state=pro_split_string(`strs`,'|',3);  #状态
			SET userId=pro_split_string(`strs`,'|',4);  #用户ID
			SET @id=pro_split_string(`strs`,'|',5);  #ID
			IF @id>0 THEN #修改
				UPDATE piling_example e SET e.plat_id=platId,e.piling_example_title=pilName,e.state=state,
					e.userId=userId WHERE e.id=@id;
				SELECT '1';
			ELSE  #添加 
				INSERT INTO piling_example VALUES(NULL,platId,pilName,state,NOW(),userId);
				SELECT '1';
			END IF;
		WHEN 2 THEN #分页查询渠道用例
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET pilName=pro_split_string(`strs`,'|',2);  #用例名称
			SET page=pro_split_string(`strs`,'|',3);  #第几页面
			SET pageSize=pro_split_string(`strs`,'|',4);  #多少条
			IF platId>0 THEN
				SELECT e.*,f.Title AS platName FROM piling_example e JOIN Dict_PlatForm f WHERE e.plat_id=f.ID  
					AND e.plat_id=platId AND e.piling_example_title LIKE CONCAT('%',pilName,'%') ORDER BY e.id LIMIT page,pageSize;
			ELSE
				SELECT e.*,f.Title AS platName FROM piling_example e JOIN Dict_PlatForm f WHERE e.plat_id=f.ID 
					AND e.piling_example_title LIKE CONCAT('%',pilName,'%') ORDER BY e.id LIMIT page,pageSize;
			END IF;
		WHEN 3 THEN #分页查询渠道用例个数
			SET platId=pro_split_string(`strs`,'|',1);  #平台ID
			SET pilName=pro_split_string(`strs`,'|',2);  #用例名称
			IF platId>0 THEN
				SELECT COUNT(*) FROM piling_example e JOIN Dict_PlatForm f WHERE e.plat_id=f.ID 
					AND e.plat_id=platId AND e.piling_example_title LIKE CONCAT('%',pilName,'%') ORDER BY e.id;
			ELSE
				SELECT COUNT(*) FROM piling_example e JOIN Dict_PlatForm f WHERE e.plat_id=f.ID 
					AND e.piling_example_title LIKE CONCAT('%',pilName,'%') ORDER BY e.id;
			END IF;
		WHEN 4 THEN #禁用和启用
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SET state=(SELECT e.state FROM piling_example e WHERE e.id=@id);
			SET @len=0;
			IF state=0 THEN
				SET @len=1;
			ELSE
				SET @len=0;
			END IF;
			UPDATE piling_example e SET e.state=@len WHERE e.id=@id;
			SELECT '1';
		WHEN 5 THEN #按ID查询渠道用例
			SET @id=pro_split_string(`strs`,'|',1);  #ID
			SELECT * FROM piling_example e WHERE e.id=@id;
	END CASE;
END;
