CREATE PROCEDURE cp_Channel_Execute_Info_GetRecordInfo(IN isExecute INT, IN pil_exa_id INT)
  BEGIN
	SELECT `id`, `pil_exa_id`, `result`, `execute_time`, `isExecute` FROM piling_execute_info t1 
	WHERE t1.`isExecute` = `isExecute`  and t1.`pil_exa_id` = `pil_exa_id`
	order by id desc;
    END;
