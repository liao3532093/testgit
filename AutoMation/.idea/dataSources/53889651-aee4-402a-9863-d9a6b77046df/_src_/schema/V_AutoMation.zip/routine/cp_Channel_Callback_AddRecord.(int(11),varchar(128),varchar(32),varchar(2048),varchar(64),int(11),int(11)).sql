CREATE PROCEDURE cp_Channel_Callback_AddRecord(IN `_Channel_CaseId`    INT, IN `_Request_url` VARCHAR(128),
                                               IN `_Request_type`      VARCHAR(32), IN `_Response_Param` VARCHAR(2048),
                                               IN `_OrderID`           VARCHAR(64), IN `_pil_model_id` INT,
                                               IN `_ExecutionRecordID` INT)
  BEGIN
	SET @ReturnValue = 0;
	SET @ModelID = (SELECT `piling_model_id` FROM `piling_exa_model` WHERE `id` = `_pil_model_id`);
	IF(@ModelID > 0)
	THEN
		Insert INTO PiLing_Channel_Callback (`Channel_CaseId`, `Channel_ModelId` ,`Request_url` ,`Request_type` ,`Response_Param` ,`OrderID`, `ExecutionRecordID`) 
		VALUES(`_Channel_CaseId` ,`_pil_model_id`  ,`_Request_url` ,`_Request_type` ,`_Response_Param` ,`_OrderID`, _ExecutionRecordID)
		;
		
		SET @RowID = last_insert_id() ;		
		
		#插入回调时 预期结果临时表
		INSERT INTO `PiLing_Channel_expected_Result`(
			`Callback_table_ID`,
			`Expected_Description`,
			`Channel_ModuleID`,
			`ExpectTypeID`,
			`Sql_ID`,
			`ExpectValue`,
			`StepNum`			
		)
		SELECT 
			@RowID,
			`exp_details`,
			`pil_model_id`,
			`exp_id`,
			`sql_id`,
			`ExpectValue`,
			`exp_num`
		FROM `piling_expected_result` 
		WHERE `pil_model_id` = @ModelID and `state` = 1 ;
		
		set @ReturnValue = last_insert_id();
	END IF;
	
	SELECT @ReturnValue;
END;
