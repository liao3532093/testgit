CREATE PROCEDURE pro_user_info(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#用户信息
	DECLARE account VARCHAR(255) DEFAULT '';
	DECLARE pwd VARCHAR(255) DEFAULT '';
	DECLARE showName VARCHAR(255) DEFAULT '';
	DECLARE lastLoginTime VARCHAR(255) DEFAULT '';
	DECLARE lastLoginIP VARCHAR(255) DEFAULT '';
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 0;

	CASE `index`
		WHEN 1 THEN  #保存用户信息
			SET account=pro_split_string(`strs`,'|',1);  #登录账户、旧密码
			SET pwd=pro_split_string(`strs`,'|',2);  #登录密码、新密码
			SET showName=pro_split_string(`strs`,'|',3);  #真实姓名
			SET @id=pro_split_string(`strs`,'|',4);  #用户ID
			IF @id>0 THEN  #修改密码
				SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.`Password`=MD5(account) AND u.ID=@id);
				IF @count>0 THEN  #可以修改
					SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.`Password`=MD5(pwd) AND u.ID=@id);
					IF @count>0 THEN #新密码和旧密码一样
						SELECT '-3';
					ELSE
						UPDATE Admin_User u SET u.`Password`=MD5(pwd) WHERE u.ID=@id;
						SELECT '1';
					END IF;
				ELSE
					SELECT '-2';
				END IF;
			ELSE
				SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.Account=account);
				IF @count>0 THEN #账号已存在
					SELECT '-1';
				ELSE
					INSERT INTO Admin_User VALUES(NULL,account,MD5(pwd),showName,NOW(),'',NOW(),false);
					SELECT '1';
				END IF;
			END IF;
		WHEN 2 THEN #分页查询用户信息
			SET showName=pro_split_string(`strs`,'|',1);  #真实姓名
			SET page=pro_split_string(`strs`,'|',2);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',3);  #多少条
			SELECT * FROM Admin_User u WHERE u.ShowName LIKE CONCAT('%',showName,'%') ORDER BY u.ID LIMIT page,pageSize;
		WHEN 3 THEN  #分页查询用户信息个数 
			SET showName=pro_split_string(`strs`,'|',1);  #真实姓名
			SELECT COUNT(*) FROM Admin_User u WHERE u.ShowName LIKE CONCAT('%',showName,'%') ORDER BY u.ID;
		WHEN 4 THEN #按ID查询用户信息
			SET @id=pro_split_string(`strs`,'|',1);  #用户信息ID
			SELECT * FROM Admin_User u WHERE u.ID=@id;
		WHEN 5 THEN #启用禁用
			SET @id=pro_split_string(`strs`,'|',1);  #用户信息ID
			SET @isLock=(SELECT u.IsLock FROM Admin_User u WHERE u.ID=@id);
			SET @flag=0;
			IF @isLock>0 THEN #已禁用
				SET @flag=0;
			ELSE
				SET @flag=1;
			END IF;
			UPDATE Admin_User u SET u.IsLock=@flag WHERE u.ID=@id;
			SELECT '1';
		WHEN 6 THEN #用户登录
			SET account=pro_split_string(`strs`,'|',1);  #登录账户
			SET pwd=pro_split_string(`strs`,'|',2);  #登录密码
			SET lastLoginIP=pro_split_string(`strs`,'|',3);  #IP地址
			SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.Account=account AND u.`Password`=MD5(pwd));
			IF @count>0 THEN #用户存在
				SET @locks=(SELECT u.IsLock FROM Admin_User u WHERE u.Account=account AND u.`Password`=MD5(pwd));
				IF @locks>0 THEN #已锁定
					SELECT NULL;
				ELSE
					SET @id=(SELECT u.ID FROM Admin_User u WHERE u.Account=account AND u.`Password`=MD5(pwd));
					UPDATE Admin_User u SET u.LastLoginIP=lastLoginIP,u.LastLoginTime=NOW() WHERE u.ID=@id;
					SELECT * FROM Admin_User u WHERE u.Account=account AND u.`Password`=MD5(pwd);
				END IF;
			ELSE
				SELECT NULL;
			END IF;
		WHEN 7 THEN #修改用户信息
			SET @oPwd=pro_split_string(`strs`,'|',1);  #旧密码
			SET @pwd=pro_split_string(`strs`,'|',2);  #新密码
			SET @uName=pro_split_string(`strs`,'|',3);  #用户名称
			SET @id=pro_split_string(`strs`,'|',4);  #用户ID	
			SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.ID=@id AND u.`Password`=MD5(@oPwd));
			IF @count>0 THEN #可以修改
				SET @count=(SELECT COUNT(*) FROM Admin_User u WHERE u.`Password`=MD5(@pwd) AND u.ID=@id);
				IF @count>0 THEN  #新密码和旧密码一样
					SELECT '-2';
				ELSE
					UPDATE Admin_User u SET u.`Password`=MD5(@pwd),u.ShowName=@uName WHERE u.ID=@id;
					SELECT '1';
				END IF;
			ELSE
				SELECT '-1';
			END IF;
	END CASE;
END;
