CREATE PROCEDURE cp_Channel_Execute_Info_UpdateRecord(IN id INT, IN result INT)
  BEGIN
	 
	UPDATE piling_execute_info i SET i.result=`result` where i.id=`id`;
	
END;
