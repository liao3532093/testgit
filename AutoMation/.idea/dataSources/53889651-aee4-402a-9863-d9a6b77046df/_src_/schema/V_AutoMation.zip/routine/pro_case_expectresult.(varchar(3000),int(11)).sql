CREATE PROCEDURE pro_case_expectresult(IN strs VARCHAR(3000), IN `index` INT)
  BEGIN
	#预测结果
	DECLARE caseModelId INT DEFAULT 0;  #所属用例模块ID
	DECLARE expectTypeId INT DEFAULT 0;  #预测类型ID
	DECLARE detail VARCHAR(255) DEFAULT '';  #预期结果详情
	DECLARE sqlId INT DEFAULT 0;  #执行的脚本ID
	DECLARE orderNum INT DEFAULT 0;  #执行的顺序
	DECLARE isEnable INT DEFAULT 0;  #是否可用
	DECLARE userId INT DEFAULT 0;  #新增人ID
	DECLARE page INT DEFAULT 0;
	DECLARE pageSize INT DEFAULT 50;

	CASE `index`
		WHEN 1 THEN  #分页查询预测结果
			SET caseModelId=pro_split_string(`strs`,'|',1);  #所属用例模块ID
			SET sqlId=pro_split_string(`strs`,'|',2);  #执行的脚本ID
			SET page=pro_split_string(`strs`,'|',3);  #第几页
			SET pageSize=pro_split_string(`strs`,'|',4);  #多少条
			IF sqlId>0 THEN
				SELECT r.ID,r.CaseModelID,r.ExPectTypeID,r.Detail,r.SqlID,r.OrderNum,r.IsEnable,r.AddUserID,r.AddTime,t.Title 
					AS expectTypeName,s.ExecuteSql AS sqlName,s.ExpectValue AS eValue
					FROM Case_ExpectResult r JOIN Dict_ExpectType t JOIN Dict_ExecuteSql s 
					WHERE r.ExpectTypeID=t.ID AND r.SqlID=s.ID AND r.CaseModelID=caseModelId 
					ORDER BY r.OrderNum LIMIT page,pageSize;
			ELSE
				SELECT r.ID,r.CaseModelID,r.ExPectTypeID,r.Detail,r.SqlID,r.OrderNum,r.IsEnable,r.AddUserID,r.AddTime,t.Title 
					AS expectTypeName FROM Case_ExpectResult r JOIN Dict_ExpectType t 
					WHERE r.ExpectTypeID=t.ID AND r.CaseModelID=caseModelId AND r.SqlID=sqlId
					ORDER BY r.OrderNum LIMIT page,pageSize;
			END IF;
		WHEN 2 THEN #分页查询预测结果个数
			SET caseModelId=pro_split_string(`strs`,'|',1);  #所属用例模块ID
			SELECT COUNT(*) FROM Case_ExpectResult r JOIN Dict_ExpectType t 
				WHERE r.ExpectTypeID=t.ID AND r.CaseModelID=caseModelId 
				ORDER BY r.OrderNum;
		WHEN 3 THEN  #保存预测结果
			SET caseModelId=pro_split_string(`strs`,'|',1);  #所属用例模块ID
			SET expectTypeId=pro_split_string(`strs`,'|',2);  #预测类型ID
			SET detail=pro_split_string(`strs`,'|',3);  #预期结果详情
			SET sqlId=pro_split_string(`strs`,'|',4);  #执行的脚本ID
			SET orderNum=pro_split_string(`strs`,'|',5);  #执行的顺序
			SET isEnable=pro_split_string(`strs`,'|',6);  #是否可用
			SET userId=pro_split_string(`strs`,'|',7);  #新增人ID
			SET @id=pro_split_string(`strs`,'|',8);  #预测结果ID
			SET @orderId=(SELECT r.OrderNum FROM Case_ExpectResult r WHERE r.CaseModelID=caseModelId AND r.ID=@id);
			SET @cont=(SELECT COUNT(*) FROM Case_ExpectResult r WHERE r.CaseModelID=caseModelId AND r.OrderNum=orderNum);
			IF @id>0 THEN  #修改
				IF @cont<=0 || @orderId=orderNum THEN
					UPDATE Case_ExpectResult r SET r.CaseModelID=caseModelId,r.ExpectTypeID=expectTypeId,r.Detail=detail,r.SqlID=sqlId,
					r.OrderNum=orderNum,r.IsEnable=isEnable,r.AddUserID=userId WHERE r.ID=@id;
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
				SELECT '-1';
			ELSE #添加 
				IF @cont<=0 THEN
					INSERT INTO Case_ExpectResult VALUES(NULL,caseModelId,expectTypeId,detail,sqlId,orderNum,isEnable,userId,NOW());
					SELECT '1';
				ELSE
					SELECT '-1';
				END IF;
				SELECT '-1';
			END IF;
		WHEN 4 THEN #启用和禁用
			SET @id=pro_split_string(`strs`,'|',1);  #预测结果ID
			SET isEnable=(SELECT r.IsEnable FROM Case_ExpectResult r WHERE r.ID=@id);
			SET @flag=0;
			IF isEnable>0 THEN #已启用
				SET @flag=0;
			ELSE
				SET @flag=1;
			END IF;
			UPDATE Case_ExpectResult r SET r.IsEnable=@flag WHERE r.ID=@id;
			SELECT '1';
		WHEN 5 THEN #按ID查询预测结果
			SET @id=pro_split_string(`strs`,'|',1);  #预测结果ID
			SELECT * FROM Case_ExpectResult r WHERE r.ID=@id;
	END CASE;
END;
